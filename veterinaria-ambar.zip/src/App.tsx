import { useState } from 'react';
import { 
  Database, Layout, Server, Award, BookOpen, GraduationCap, Github, User, ShieldAlert 
} from 'lucide-react';

import VeterinarySystem from './components/VeterinarySystem';
import DatabaseHASimulator from './components/DatabaseHASimulator';

import { 
  INITIAL_PROPIETARIOS, 
  INITIAL_PACIENTES, 
  INITIAL_DOCTORES, 
  INITIAL_HISTORIAL_CLINICO, 
  INITIAL_CITAS, 
  ESTETICO_SERVICIOS 
} from './data/mockData';

import { Propietario, Paciente, Doctor, HistorialClinico, CitaMedica } from './types';

export default function App() {
  // Shared state that can be mutated in the system and queried in the SQL console!
  const [propietarios, setPropietarios] = useState<Propietario[]>(INITIAL_PROPIETARIOS);
  const [pacientes, setPacientes] = useState<Paciente[]>(INITIAL_PACIENTES);
  const [doctores, setDoctores] = useState<Doctor[]>(INITIAL_DOCTORES);
  const [historialClinico, setHistorialClinico] = useState<HistorialClinico[]>(INITIAL_HISTORIAL_CLINICO);
  const [citas, setCitas] = useState<CitaMedica[]>(INITIAL_CITAS);
  const [servicios] = useState(ESTETICO_SERVICIOS);

  // Core navigation: system vs database lab
  const [activeModule, setActiveModule] = useState<'system' | 'db_lab'>('system');

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-blue-500 selection:text-white">
      
      {/* Top Academic Context Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          
          {/* Left: UTP Information */}
          <div className="flex items-center gap-3">
            <div className="bg-red-600 text-white font-extrabold px-3 py-1.5 rounded-lg text-sm tracking-widest shadow-sm">
              UTP
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] uppercase font-bold tracking-wider text-red-600">Universidad Tecnológica del Perú</span>
                <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                <span className="text-[10px] font-semibold text-slate-500">Sección 19668</span>
              </div>
              <h2 className="text-xs font-bold text-slate-700">
                Curso Integrador I: Sistemas Software
              </h2>
            </div>
          </div>

          {/* Center: Author */}
          <div className="flex items-center gap-2 bg-slate-100 px-3.5 py-1.5 rounded-full border border-slate-200 text-xs">
            <GraduationCap className="w-4 h-4 text-blue-600" />
            <span className="text-slate-500">Estudiante:</span>
            <span className="font-extrabold text-slate-800">Willy Michael Hinostroza Moreno</span>
          </div>

          {/* Right: Academic Year */}
          <div className="text-right text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            PROYECTO ACADÉMICO • 2026
          </div>

        </div>
      </div>

      {/* Main Brand / Navigation Header */}
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-40 border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <span className="p-2 bg-blue-600 rounded-xl shadow-sm">
              <Database className="w-6 h-6 text-white" />
            </span>
            <div>
              <h1 className="text-lg font-black tracking-tight text-slate-900 flex items-center gap-1.5">
                Clínica Veterinaria Ambar
              </h1>
              <p className="text-[11px] text-slate-500">
                Arquitectura de Software Relacional, Alta Disponibilidad & Escalabilidad
              </p>
            </div>
          </div>

          {/* Switch Active Module Tab bar */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 w-full sm:w-auto">
            <button
              onClick={() => setActiveModule('system')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                activeModule === 'system' 
                  ? 'bg-blue-600 text-white shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layout className="w-4 h-4" />
              Sistema Clínico (Prototipo)
            </button>
            <button
              onClick={() => setActiveModule('db_lab')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                activeModule === 'db_lab' 
                  ? 'bg-blue-600 text-white shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Server className="w-4 h-4" />
              Laboratorio de Base de Datos
            </button>
          </div>

        </div>
      </header>

      {/* Dynamic Main Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-8">
        
        {/* Short Spanish Greeting / Introduction info */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
          <div className="space-y-1">
            <div className="text-[10px] uppercase font-bold tracking-widest text-blue-600">Propuesta de Arquitectura de Sistemas</div>
            <h3 className="text-sm font-bold text-slate-900">
              {activeModule === 'system' 
                ? 'Panel de Control de Atención y Operaciones de la Clínica Ambar' 
                : 'Simulador de Topologías, Failover en Base de Datos MySQL y Scripts PHP'}
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
              {activeModule === 'system'
                ? 'Este panel simula las pantallas y flujos descritos en tu informe (Registro de Propietario, Ficha de Paciente con historial clínico, Calendario semanal interactivo y Catálogo de Estética). Todo cambio que realices aquí actualiza la base de datos simulada en tiempo real.'
                : 'Prueba la resiliencia e inyecta tráfico masivo. Simula la desconexión del servidor MySQL Master para observar cómo la réplica se promociona a Master (Failover) de manera automática y copia el código estructurado en PHP (PDO) y SQL.'}
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-lg shrink-0">
            <BookOpen className="w-4 h-4 text-emerald-600" />
            <div className="text-[10px] text-left">
              <span className="block font-bold text-slate-700">Docente de Asignatura:</span>
              <span className="text-slate-500">Jonathan Loja Yoplac</span>
            </div>
          </div>
        </div>

        {/* Component Stage */}
        {activeModule === 'system' ? (
          <VeterinarySystem 
            propietarios={propietarios}
            pacientes={pacientes}
            doctores={doctores}
            historialClinico={historialClinico}
            citas={citas}
            servicios={servicios}
            setPropietarios={setPropietarios}
            setPacientes={setPacientes}
            setCitas={setCitas}
            setHistorialClinico={setHistorialClinico}
          />
        ) : (
          <DatabaseHASimulator 
            propietarios={propietarios}
            pacientes={pacientes}
            doctores={doctores}
            historialClinico={historialClinico}
            citas={citas}
            servicios={servicios}
            setPropietarios={setPropietarios}
            setPacientes={setPacientes}
            setDoctores={setDoctores}
          />
        )}

      </main>

      {/* Footer bar */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-[11px] text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <b>Clínica Veterinaria Ambar E.I.R.L.</b> — Proyecto integrador académico.
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <span>Desarrollado en React, TypeScript y Tailwind CSS</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
