import { Propietario, Paciente, Doctor, HistorialClinico, CitaMedica, EsteticoServicio, AtencionEstetica } from '../types';

export const INITIAL_PROPIETARIOS: Propietario[] = [
  { idPropietario: 1, nombre: "Juan Pérez", telefono: "987654321", email: "juan.perez@email.com", direccion: "Av. Las Flores 123, Villa El Salvador" },
  { idPropietario: 2, nombre: "Ana Gómez", telefono: "912345678", email: "ana.gomez@email.com", direccion: "Sector 3, Grupo 15, Villa El Salvador" },
  { idPropietario: 3, nombre: "María López", telefono: "934567890", email: "maria.lopez@email.com", direccion: "Mz. D Lote 5, Urbanización Pachacamac" },
  { idPropietario: 4, nombre: "Carlos García", telefono: "956789012", email: "carlos.garcia@email.com", direccion: "Av. Central 789, Villa El Salvador" }
];

export const INITIAL_PACIENTES: Paciente[] = [
  { idPaciente: 1, nombre: "Max", especie: "Canino", raza: "Labrador", edad: 5, fechaNacimiento: "2021-03-12", idPropietario: 1 },
  { idPaciente: 2, nombre: "Luna", especie: "Felino", raza: "Siamés", edad: 3, fechaNacimiento: "2023-05-20", idPropietario: 2 },
  { idPaciente: 3, nombre: "Rex", especie: "Canino", raza: "Pastor Alemán", edad: 4, fechaNacimiento: "2022-07-15", idPropietario: 3 },
  { idPaciente: 4, nombre: "Mimi", especie: "Felino", raza: "Persa", edad: 2, fechaNacimiento: "2024-01-10", idPropietario: 4 },
  { idPaciente: 5, nombre: "Bella", especie: "Canino", raza: "Beagle", edad: 3, fechaNacimiento: "2023-09-05", idPropietario: 1 },
  { idPaciente: 6, nombre: "Toby", especie: "Canino", raza: "Cocker Spaniel", edad: 6, fechaNacimiento: "2020-11-22", idPropietario: 2 },
  { idPaciente: 7, nombre: "Firulais", especie: "Canino", raza: "Mestizo", edad: 2, fechaNacimiento: "2024-02-14", idPropietario: 4 }
];

export const INITIAL_DOCTORES: Doctor[] = [
  { idDoctor: 1, nombre: "Dr. Carlos Pérez", especialidad: "Medicina General y Cirugía" },
  { idDoctor: 2, nombre: "Dra. Ana Gómez", especialidad: "Dermatología y Estética" },
  { idDoctor: 3, nombre: "Dr. Juan Rodríguez", especialidad: "Cardiología y Ecografía" },
  { idDoctor: 4, nombre: "Dra. Sofía Sánchez", especialidad: "Pediatría y Vacunación" }
];

export const INITIAL_HISTORIAL_CLINICO: HistorialClinico[] = [
  { idHistorial: 1, idPaciente: 1, fecha: "2024-05-12", diagnostico: "Otitis bilateral severa", tratamiento: "Limpieza de conducto + Gotas antibióticas por 7 días" },
  { idHistorial: 2, idPaciente: 1, fecha: "2024-03-28", diagnostico: "Alergia en Piel (Dermatitis atópica)", tratamiento: "Antihistamínicos + Champú de avena medicado" },
  { idHistorial: 3, idPaciente: 1, fecha: "2024-02-10", diagnostico: "Gastroenteritis aguda", tratamiento: "Dieta blanda, suero oral + Antibiótico oral por 5 días" },
  { idHistorial: 4, idPaciente: 1, fecha: "2024-01-15", diagnostico: "Chequeo General", tratamiento: "Vacuna Quíntuple + Desparasitación interna completa" },
  
  { idHistorial: 5, idPaciente: 2, fecha: "2024-06-18", diagnostico: "Gripe felina leve", tratamiento: "Inhalaciones + Mucolítico pediátrico" },
  { idHistorial: 6, idPaciente: 3, fecha: "2024-04-05", diagnostico: "Herida leve en pata posterior", tratamiento: "Limpieza quirúrgica y vendaje protector por 3 días" }
];

export const ESTETICO_SERVICIOS: EsteticoServicio[] = [
  { idServicio: 1, nombre: "Baño Completo", costo: 20.00, duracionMinutos: 30 },
  { idServicio: 2, nombre: "Corte de Pelo Estilizado", costo: 35.00, duracionMinutos: 45 },
  { idServicio: 3, nombre: "Limpieza Dental por Ultrasonido", costo: 50.00, duracionMinutos: 40 },
  { idServicio: 4, nombre: "Desparasitación Externa (Pulgas y Garrapatas)", costo: 25.00, duracionMinutos: 20 }
];

export const INITIAL_CITAS: CitaMedica[] = [
  { idCita: 1, idPaciente: 3, idDoctor: 1, fecha: "2026-07-20", hora: "09:00", motivo: "Rex - Consulta general de control", tipo: "Medica" },
  { idCita: 2, idPaciente: 2, idDoctor: 4, fecha: "2026-07-21", hora: "10:00", motivo: "Luna - Vacuna triple felina", tipo: "Medica" },
  { idCita: 3, idPaciente: 1, idDoctor: 3, fecha: "2026-07-22", hora: "11:00", motivo: "Max - Chequeo de oído y control otitis", tipo: "Medica" },
  { idCita: 4, idPaciente: 4, idDoctor: 2, fecha: "2026-07-23", hora: "10:00", motivo: "Mimi - Control dermatológico", tipo: "Medica" },
  { idCita: 5, idPaciente: 6, idDoctor: 1, fecha: "2026-07-23", hora: "11:00", motivo: "Toby - Cirugía programada (esterilización)", tipo: "Medica" },
  { idCita: 6, idPaciente: 5, idDoctor: 2, fecha: "2026-07-24", hora: "09:30", motivo: "Bella - Limpieza de oídos y glándulas", tipo: "Medica" },
  { idCita: 7, idPaciente: 7, idDoctor: 4, fecha: "2026-07-24", hora: "11:00", motivo: "Firulais - Baño medicado y corte de uñas", tipo: "Estetica", idServicio: 1 }
];

export const MYSQL_SCHEMA_SQL = `-- ==========================================
-- SCRIPT DE BASE DE DATOS: CLINICA VETERINARIA AMBAR
-- Diseñado para Alta Disponibilidad (Replicación) y Escalabilidad
-- ==========================================

CREATE DATABASE IF NOT EXISTS veterinaria_ambar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE veterinaria_ambar;

-- 1. Tabla Propietario (Cliente)
CREATE TABLE propietario (
  idPropietario INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  telefono VARCHAR(20) NOT NULL,
  email VARCHAR(100) NOT NULL,
  direccion TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_propietario_nombre (nombre)
) ENGINE=InnoDB;

-- 2. Tabla Paciente (Mascota)
CREATE TABLE paciente (
  idPaciente INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  especie VARCHAR(50) NOT NULL,
  raza VARCHAR(50) NOT NULL,
  edad INT NOT NULL,
  fechaNacimiento DATE NOT NULL,
  idPropietario INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (idPropietario) REFERENCES propietario(idPropietario) ON DELETE CASCADE,
  INDEX idx_paciente_propietario (idPropietario),
  INDEX idx_paciente_nombre (nombre)
) ENGINE=InnoDB;

-- 3. Tabla Doctor (Veterinario)
CREATE TABLE doctor (
  idDoctor INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  especialidad VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Tabla Historial Clínico
CREATE TABLE historial_clinico (
  idHistorial INT AUTO_INCREMENT PRIMARY KEY,
  idPaciente INT NOT NULL,
  fecha DATE NOT NULL,
  diagnostico TEXT NOT NULL,
  tratamiento TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (idPaciente) REFERENCES paciente(idPaciente) ON DELETE CASCADE,
  INDEX idx_historial_paciente (idPaciente)
) ENGINE=InnoDB;

-- 5. Tabla Agenda / Citas
CREATE TABLE cita_medica (
  idCita INT AUTO_INCREMENT PRIMARY KEY,
  idPaciente INT NOT NULL,
  idDoctor INT NULL,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  motivo VARCHAR(255) NOT NULL,
  tipo ENUM('Medica', 'Estetica') NOT NULL DEFAULT 'Medica',
  idServicio INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (idPaciente) REFERENCES paciente(idPaciente) ON DELETE CASCADE,
  FOREIGN KEY (idDoctor) REFERENCES doctor(idDoctor) ON DELETE SET NULL,
  INDEX idx_cita_fecha_hora (fecha, hora)
) ENGINE=InnoDB;

-- 6. Tabla Servicios Estéticos (Catálogo)
CREATE TABLE estetico_servicio (
  idServicio INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  costo DECIMAL(10,2) NOT NULL,
  duracionMinutos INT NOT NULL
) ENGINE=InnoDB;

-- 7. Tabla Atención Estética (Registro de realización)
CREATE TABLE atencion_estetica (
  idAtencion INT AUTO_INCREMENT PRIMARY KEY,
  idPaciente INT NOT NULL,
  idServicio INT NOT NULL,
  notas TEXT NULL,
  costoServicio DECIMAL(10,2) NOT NULL,
  fecha DATE NOT NULL,
  comprobante_generado TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (idPaciente) REFERENCES paciente(idPaciente) ON DELETE CASCADE,
  FOREIGN KEY (idServicio) REFERENCES estetico_servicio(idServicio),
  INDEX idx_atencion_fecha (fecha)
) ENGINE=InnoDB;

-- ==========================================
-- REGISTROS INICIALES (SEMILLA / SEEDER)
-- ==========================================
INSERT INTO doctor (nombre, especialidad) VALUES
('Dr. Carlos Pérez', 'Medicina General y Cirugía'),
('Dra. Ana Gómez', 'Dermatología y Estética'),
('Dr. Juan Rodríguez', 'Cardiología y Ecografía'),
('Dra. Sofía Sánchez', 'Pediatría y Vacunación');

INSERT INTO estetico_servicio (nombre, costo, duracionMinutos) VALUES
('Baño Completo', 20.00, 30),
('Corte de Pelo Estilizado', 35.00, 45),
('Limpieza Dental por Ultrasonido', 50.00, 40),
('Desparasitación Externa (Pulgas y Garrapatas)', 25.00, 20);
`;

export const PHP_CONNECTION_CODE = `<?php
/**
 * CLASE DE CONEXIÓN A BASE DE DATOS: CLINICA VETERINARIA AMBAR
 * Implementa el patrón Singleton y soporta alta disponibilidad mediante
 * selección automática de nodos de Lectura/Escritura (Read/Write Splitting)
 */

class Database {
    private static $write_instance = null;
    private static $read_instances = [];
    
    // Configuración para entorno escalable (Cluster Master-Replica)
    private static $hosts_write = ['db-master.veterinaria-ambar.internal']; // Servidor de Escritura
    private static $hosts_read = [
        'db-replica-1.veterinaria-ambar.internal', // Réplica de lectura 1
        'db-replica-2.veterinaria-ambar.internal'  // Réplica de lectura 2
    ];
    
    private static $db_user = 'ambar_admin';
    private static $db_pass = 'Secr3t_Ambar_Pass_2026';
    private static $db_name = 'veterinaria_ambar';
    private static $db_port = 3306;

    /**
     * Obtiene conexión para ESCRITURA (Inserciones, Actualizaciones, Eliminaciones)
     * Apunta al nodo Master de la base de datos.
     */
    public static function getWriteConnection() {
        if (self::$write_instance === null) {
            try {
                // En producción real, se utiliza el host máster
                $host = self::$hosts_write[0];
                $dsn = "mysql:host=$host;dbname=" . self::$db_name . ";port=" . self::$db_port . ";charset=utf8mb4";
                
                self::$write_instance = new PDO($dsn, self::$db_user, self::$db_pass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_TIMEOUT => 3 // Timeout corto para Failover rápido
                ]);
            } catch (PDOException $e) {
                // FAILOVER AUTOMÁTICO: Si el master cae, el sistema de HA promueve una réplica.
                // Aquí intentamos conectarnos a la primera réplica habilitada temporalmente como contingencia de sólo lectura
                error_log("Fallo en Master DB: " . $e->getMessage() . ". Activando Contingencia.");
                return self::getReadConnection(); 
            }
        }
        return self::$write_instance;
    }

    /**
     * Obtiene conexión para LECTURA (Consultas SELECT)
     * Distribuye la carga aleatoriamente entre las Réplicas de Lectura (Balanceo).
     */
    public static function getReadConnection() {
        if (empty(self::$read_instances)) {
            // Selecciona un host de lectura aleatorio para balancear carga (Round Robin o Random)
            $hosts = self::$hosts_read;
            shuffle($hosts); // Aleatoriedad para balancear consultas
            
            foreach ($hosts as $host) {
                try {
                    $dsn = "mysql:host=$host;dbname=" . self::$db_name . ";port=" . self::$db_port . ";charset=utf8mb4";
                    $conn = new PDO($dsn, self::$db_user, self::$db_pass, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_TIMEOUT => 2
                    ]);
                    self::$read_instances[] = $conn;
                    return $conn; // Retorna la primera réplica que responda correctamente
                } catch (PDOException $e) {
                    error_log("Error conectando a réplica $host: " . $e->getMessage());
                    // Continúa con la siguiente réplica si la actual falla
                }
            }
            
            // Si todas las réplicas de lectura fallan, recurre al Master como último recurso
            return self::getWriteConnection();
        }
        return self::$read_instances[0];
    }
}

/**
 * EJEMPLO DE USO DE LA CLASE EN CONTROLADORES PHP
 */

// 1. Guardar Propietario (Escribe en Master)
function registrarPropietario($nombre, $telefono, $email, $direccion) {
    try {
        $db = Database::getWriteConnection(); // Conexión de Escritura
        $stmt = $db->prepare("INSERT INTO propietario (nombre, telefono, email, direccion) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nombre, $telefono, $email, $direccion]);
        return $db->lastInsertId();
    } catch (PDOException $e) {
        die("Error al registrar propietario: " . $e->getMessage());
    }
}

// 2. Consultar Paciente por Propietario (Lee de Réplicas)
function listarPacientesPorPropietario($idPropietario) {
    try {
        $db = Database::getReadConnection(); // Conexión de Lectura (Balanceada)
        $stmt = $db->prepare("SELECT * FROM paciente WHERE idPropietario = ?");
        $stmt->execute([$idPropietario]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        die("Error al consultar pacientes: " . $e->getMessage());
    }
}
?>`;
