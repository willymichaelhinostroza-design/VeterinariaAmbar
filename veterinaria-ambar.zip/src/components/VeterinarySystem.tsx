import React, { useState } from 'react';
import { 
  Dog, Cat, Calendar, User, Search, Scissors, FileText, Check, Printer, 
  ArrowLeft, CreditCard, Plus, FileSpreadsheet, PlusCircle, Trash2, Clock, MapPin, Phone, Mail, FilePlus
} from 'lucide-react';
import { Propietario, Paciente, Doctor, HistorialClinico, CitaMedica, EsteticoServicio } from '../types';

interface VeterinarySystemProps {
  propietarios: Propietario[];
  pacientes: Paciente[];
  doctores: Doctor[];
  historialClinico: HistorialClinico[];
  citas: CitaMedica[];
  servicios: EsteticoServicio[];
  setPropietarios: React.Dispatch<React.SetStateAction<Propietario[]>>;
  setPacientes: React.Dispatch<React.SetStateAction<Paciente[]>>;
  setCitas: React.Dispatch<React.SetStateAction<CitaMedica[]>>;
  setHistorialClinico: React.Dispatch<React.SetStateAction<HistorialClinico[]>>;
}

export default function VeterinarySystem({
  propietarios,
  pacientes,
  doctores,
  historialClinico,
  citas,
  servicios,
  setPropietarios,
  setPacientes,
  setCitas,
  setHistorialClinico
}: VeterinarySystemProps) {
  
  // Navigation
  const [currentSection, setCurrentSection] = useState<'propietario' | 'paciente' | 'calendario' | 'estetica'>('paciente');

  // Form States - Propietario
  const [pNombre, setPNombre] = useState('');
  const [pDireccion, setPDireccion] = useState('');
  const [pTelefono, setPTelefono] = useState('');
  const [pEmail, setPEmail] = useState('');
  const [pSuccessMsg, setPSuccessMsg] = useState('');

  // Form States - Paciente / Mascotas
  const [selectedPacienteId, setSelectedPacienteId] = useState<number>(1);
  const [nuevaEntradaDiag, setNuevaEntradaDiag] = useState('');
  const [nuevaEntradaTrat, setNuevaEntradaTrat] = useState('');
  const [showAddHistorialModal, setShowAddHistorialModal] = useState(false);
  
  // Form States - Nueva Mascota
  const [showAddPacienteModal, setShowAddPacienteModal] = useState(false);
  const [mNombre, setMNombre] = useState('');
  const [mEspecie, setMEspecie] = useState('Canino');
  const [mRaza, setMRaza] = useState('');
  const [mEdad, setMEdad] = useState(1);
  const [mNacimiento, setMNacimiento] = useState('');
  const [mPropietarioId, setMPropietarioId] = useState<number>(1);

  // Form States - Nueva Cita
  const [showAddCitaModal, setShowAddCitaModal] = useState(false);
  const [cPacienteId, setCPacienteId] = useState<number>(1);
  const [cDoctorId, setCDoctorId] = useState<number>(1);
  const [cFecha, setCFecha] = useState('2026-07-20');
  const [cHora, setCHora] = useState('09:00');
  const [cMotivo, setCMotivo] = useState('');
  const [cTipo, setCTipo] = useState<'Medica' | 'Estetica'>('Medica');

  // Selected Cita Detail State
  const [selectedCitaDetail, setSelectedCitaDetail] = useState<CitaMedica | null>(null);

  // Estetica States
  const [esteticaPacienteId, setEsteticaPacienteId] = useState<number>(1);
  const [esteticaServiciosId, setEsteticaServiciosId] = useState<number[]>([1]);
  const [esteticaDuracion, setEsteticaDuracion] = useState('45 minutos');
  const [esteticaNotas, setEsteticaNotas] = useState('Baño con shampoo medicado. Corte de pelo estilo verano.');
  const [showTicket, setShowTicket] = useState(false);
  const [ticketDetails, setTicketDetails] = useState<any | null>(null);

  // Search
  const [searchQuery, setSearchQuery] = useState('');

  // Computed Values
  const selectedPaciente = pacientes.find(p => p.idPaciente === selectedPacienteId) || pacientes[0];
  const selectedPacientePropietario = selectedPaciente 
    ? propietarios.find(o => o.idPropietario === selectedPaciente.idPropietario) 
    : null;
  const selectedPacienteHistorial = historialClinico.filter(h => h.idPaciente === selectedPacienteId);

  // Registering Propietario
  const registrarPropietario = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pNombre || !pTelefono) {
      alert("Por favor rellene al menos el Nombre y Teléfono.");
      return;
    }
    const nuevo: Propietario = {
      idPropietario: propietarios.length + 1,
      nombre: pNombre,
      direccion: pDireccion || "No especificada",
      telefono: pTelefono,
      email: pEmail || "sin@correo.com"
    };
    setPropietarios(prev => [...prev, nuevo]);
    setMPropietarioId(nuevo.idPropietario); // auto-select as owner for new pet
    setPSuccessMsg("¡Propietario registrado con éxito en el sistema!");
    setPNombre('');
    setPDireccion('');
    setPTelefono('');
    setPEmail('');
    setTimeout(() => {
      setPSuccessMsg('');
      setCurrentSection('paciente'); // go back to register pet
    }, 2500);
  };

  // Registering Paciente
  const registrarPaciente = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mNombre || !mRaza) {
      alert("Por favor complete el Nombre y la Raza de la mascota.");
      return;
    }
    const nuevo: Paciente = {
      idPaciente: pacientes.length + 1,
      nombre: mNombre,
      especie: mEspecie,
      raza: mRaza,
      edad: Number(mEdad),
      fechaNacimiento: mNacimiento || "2024-01-01",
      idPropietario: Number(mPropietarioId)
    };
    setPacientes(prev => [...prev, nuevo]);
    setSelectedPacienteId(nuevo.idPaciente);
    setMNombre('');
    setMRaza('');
    setMEdad(1);
    setMNacimiento('');
    setShowAddPacienteModal(false);
  };

  // Add Clinical Entry
  const registrarHistorial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nuevaEntradaDiag || !nuevaEntradaTrat) {
      alert("Por favor completa el diagnóstico y tratamiento.");
      return;
    }
    const nuevo: HistorialClinico = {
      idHistorial: historialClinico.length + 1,
      idPaciente: selectedPacienteId,
      fecha: new Date().toISOString().split('T')[0],
      diagnostico: nuevaEntradaDiag,
      tratamiento: nuevaEntradaTrat
    };
    setHistorialClinico(prev => [nuevo, ...prev]);
    setNuevaEntradaDiag('');
    setNuevaEntradaTrat('');
    setShowAddHistorialModal(false);
  };

  // Book Appointment
  const registrarCita = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cMotivo) {
      alert("Por favor ingrese el motivo de la cita.");
      return;
    }
    const nuevo: CitaMedica = {
      idCita: citas.length + 1,
      idPaciente: Number(cPacienteId),
      idDoctor: cTipo === 'Medica' ? Number(cDoctorId) : undefined,
      fecha: cFecha,
      hora: cHora,
      motivo: cMotivo,
      tipo: cTipo
    };
    setCitas(prev => [...prev, nuevo]);
    setCMotivo('');
    setShowAddCitaModal(false);
  };

  // Handle Aesthetic Billing
  const registrarAtencionEstetica = () => {
    const p = pacientes.find(x => x.idPaciente === esteticaPacienteId);
    const o = p ? propietarios.find(x => x.idPropietario === p.idPropietario) : null;
    
    // Sum prices of selected services
    const servicesObjects = esteticaServiciosId.map(id => servicios.find(s => s.idServicio === id)).filter(Boolean);
    const total = servicesObjects.reduce((sum, s) => sum + (s?.costo || 0), 0);

    const ticket = {
      idComprobante: `TK-${Math.floor(1000 + Math.random() * 9000)}`,
      fecha: new Date().toLocaleDateString('es-PE'),
      hora: new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit' }),
      cliente: o ? o.nombre : "Consumidor Final",
      ruc: "20602702805", // RUC Clinica Ambar from Word Doc
      telefono: o ? o.telefono : "-",
      direccion: o ? o.direccion : "-",
      mascota: p ? `${p.nombre} (${p.especie})` : "Mascota",
      servicios: servicesObjects,
      notas: esteticaNotas,
      duracion: esteticaDuracion,
      total: total
    };

    setTicketDetails(ticket);
    setShowTicket(true);
  };

  // Filter patients based on search
  const filteredPacientes = pacientes.filter(p => {
    const propName = propietarios.find(o => o.idPropietario === p.idPropietario)?.nombre || '';
    const query = searchQuery.toLowerCase();
    return p.nombre.toLowerCase().includes(query) || 
           p.especie.toLowerCase().includes(query) || 
           p.raza.toLowerCase().includes(query) || 
           propName.toLowerCase().includes(query);
  });

  // Hours array for Calendar
  const horasFiltro = ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00"];
  // Days map for Calendar week
  const diasSemana = [
    { nombre: "Lunes", fecha: "2026-07-20", numero: 14 },
    { nombre: "Martes", fecha: "2026-07-21", numero: 15 },
    { nombre: "Miércoles", fecha: "2026-07-22", numero: 16 },
    { nombre: "Jueves", fecha: "2026-07-23", numero: 17 },
    { nombre: "Viernes", fecha: "2026-07-24", numero: 18 },
    { nombre: "Sábado", fecha: "2026-07-25", numero: 19 }
  ];

  return (
    <div className="bg-slate-50 text-slate-800 rounded-xl border border-slate-200 shadow-xl overflow-hidden font-sans">
      
      {/* Top Clinical Bar */}
      <div className="bg-emerald-600 text-white px-6 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
            <span className="p-1.5 bg-emerald-700 rounded-lg">
              <Dog className="w-5 h-5 text-emerald-100" />
            </span>
            Clínica Veterinaria Ambar E.I.R.L.
          </h1>
          <p className="text-xs text-emerald-100/80 mt-0.5">
            RUC: 20602702805 | Dirección: Sector 3, Grupo 25, Mz. O, Lote 1 – Villa el Salvador
          </p>
        </div>

        {/* Local Navigation Buttons */}
        <div className="flex flex-wrap gap-1.5 bg-emerald-700/50 p-1 rounded-lg">
          <button
            onClick={() => { setCurrentSection('paciente'); setShowTicket(false); }}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${currentSection === 'paciente' ? 'bg-white text-emerald-700 shadow' : 'text-emerald-100 hover:text-white'}`}
          >
            Fichas & Pacientes
          </button>
          <button
            onClick={() => { setCurrentSection('propietario'); setShowTicket(false); }}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${currentSection === 'propietario' ? 'bg-white text-emerald-700 shadow' : 'text-emerald-100 hover:text-white'}`}
          >
            Nuevo Propietario
          </button>
          <button
            onClick={() => { setCurrentSection('calendario'); setShowTicket(false); }}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${currentSection === 'calendario' ? 'bg-white text-emerald-700 shadow' : 'text-emerald-100 hover:text-white'}`}
          >
            Agenda Inteligente
          </button>
          <button
            onClick={() => { setCurrentSection('estetica'); setShowTicket(false); }}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${currentSection === 'estetica' ? 'bg-white text-emerald-700 shadow' : 'text-emerald-100 hover:text-white'}`}
          >
            Spa y Estética
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="p-6">
        
        {/* SECTION 1: PROPIETARIO REGISTRATION FORM */}
        {currentSection === 'propietario' && (
          <div className="max-w-2xl mx-auto bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
            <div className="text-center space-y-1">
              <User className="w-8 h-8 text-emerald-600 mx-auto" />
              <h3 className="text-lg font-bold text-slate-800">Registro de Propietario</h3>
              <p className="text-xs text-slate-500">Complete el formulario para registrar un nuevo propietario en la base de datos.</p>
            </div>

            {pSuccessMsg && (
              <div className="bg-emerald-50 border border-emerald-300 text-emerald-700 px-4 py-3 rounded-lg text-xs font-bold text-center animate-fade-in">
                {pSuccessMsg}
              </div>
            )}

            <form onSubmit={registrarPropietario} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Nombre Completo *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ingrese nombre completo"
                    value={pNombre}
                    onChange={(e) => setPNombre(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Teléfono *</label>
                  <input
                    type="tel"
                    required
                    placeholder="Ingrese teléfono"
                    value={pTelefono}
                    onChange={(e) => setPTelefono(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-600">Dirección</label>
                <input
                  type="text"
                  placeholder="Ingrese dirección"
                  value={pDireccion}
                  onChange={(e) => setPDireccion(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-600">Email</label>
                <input
                  type="email"
                  placeholder="Ingrese correo electrónico"
                  value={pEmail}
                  onChange={(e) => setPEmail(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div className="flex gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCurrentSection('paciente')}
                  className="flex-1 py-2 text-xs font-bold text-slate-600 border border-slate-200 rounded hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-bold bg-emerald-600 text-white rounded hover:bg-emerald-500 shadow active:scale-95 transition-all"
                >
                  Registrar Propietario
                </button>
              </div>
            </form>
          </div>
        )}

        {/* SECTION 2: FICHA DEL PACIENTE & HISTORIAL */}
        {currentSection === 'paciente' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Sidebar search / select mascot */}
            <div className="lg:col-span-1 bg-white p-4 rounded-xl border border-slate-200 space-y-4 shadow-sm">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-700">Listado de Mascotas</span>
                <button
                  onClick={() => setShowAddPacienteModal(true)}
                  className="p-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg flex items-center gap-1 text-[10px] font-bold"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  Nueva Mascota
                </button>
              </div>

              {/* Search bar */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="Buscar mascota, especie o dueño..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs pl-8 pr-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-emerald-500 outline-none"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              </div>

              {/* Pets feed */}
              <div className="space-y-1.5 max-h-[360px] overflow-y-auto scrollbar-thin">
                {filteredPacientes.map(p => {
                  const owner = propietarios.find(o => o.idPropietario === p.idPropietario);
                  const isSelected = p.idPaciente === selectedPacienteId;
                  return (
                    <button
                      key={p.idPaciente}
                      onClick={() => setSelectedPacienteId(p.idPaciente)}
                      className={`w-full text-left p-2.5 rounded-lg border transition-all flex items-center justify-between ${
                        isSelected 
                          ? 'bg-emerald-50/70 border-emerald-500 text-emerald-900 shadow-sm font-semibold' 
                          : 'border-slate-100 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        {p.especie === 'Canino' ? (
                          <span className={`p-1.5 rounded-full ${isSelected ? 'bg-emerald-200 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                            <Dog className="w-4 h-4" />
                          </span>
                        ) : (
                          <span className={`p-1.5 rounded-full ${isSelected ? 'bg-emerald-200 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                            <Cat className="w-4 h-4" />
                          </span>
                        )}
                        <div>
                          <div className="text-xs">{p.nombre}</div>
                          <div className="text-[10px] text-slate-500">{p.raza} • {p.edad} años</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[9px] text-slate-400 uppercase tracking-tight">Dueño</div>
                        <div className="text-[10px] text-slate-600">{owner ? owner.nombre.split(' ')[0] : '-'}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Patient File & clinical history */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Pet metadata card */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100 shadow-inner">
                    {selectedPaciente?.especie === 'Canino' ? <Dog className="w-8 h-8" /> : <Cat className="w-8 h-8" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
                      Ficha de Paciente: {selectedPaciente?.nombre}
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full uppercase font-bold">
                        {selectedPaciente?.especie}
                      </span>
                    </h3>
                    
                    {/* Specifications list */}
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-1.5 text-xs text-slate-600">
                      <div><span className="font-semibold">Raza:</span> {selectedPaciente?.raza}</div>
                      <div><span className="font-semibold">Edad:</span> {selectedPaciente?.edad} años</div>
                      <div><span className="font-semibold">Propietario:</span> {selectedPacientePropietario?.nombre}</div>
                      <div><span className="font-semibold">Teléfono:</span> {selectedPacientePropietario?.telefono}</div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 w-full md:w-auto">
                  <button 
                    onClick={() => {
                      alert(`Editar mascota: ${selectedPaciente?.nombre} (${selectedPaciente?.raza})`);
                    }}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-bold transition-all"
                  >
                    Editar Mascota
                  </button>
                  <button 
                    onClick={() => setCurrentSection('calendario')}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition-all shadow"
                  >
                    Nueva Cita Médica
                  </button>
                </div>
              </div>

              {/* Clinical History Table */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
                  <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    Historial Clínico
                  </h4>
                  <button
                    onClick={() => setShowAddHistorialModal(true)}
                    className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold rounded flex items-center gap-1 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Añadir Entrada
                  </button>
                </div>

                <div className="overflow-x-auto rounded border border-slate-100">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-100 text-[10px] text-slate-500 font-bold uppercase">
                        <th className="p-3">Fecha</th>
                        <th className="p-3">Diagnóstico</th>
                        <th className="p-3">Tratamiento Realizado</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                      {selectedPacienteHistorial.length > 0 ? (
                        selectedPacienteHistorial.map((entry) => (
                          <tr key={entry.idHistorial} className="hover:bg-slate-50/50 transition-all">
                            <td className="p-3 font-semibold text-slate-500 whitespace-nowrap">
                              {entry.fecha.split('-').reverse().join('/')}
                            </td>
                            <td className="p-3 font-semibold text-slate-800">{entry.diagnostico}</td>
                            <td className="p-3 text-slate-600">{entry.tratamiento}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={3} className="p-8 text-center text-slate-400 italic">
                            No hay entradas de historial clínico registradas para {selectedPaciente?.nombre}.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* SECTION 3: CALENDAR & APPOINTMENTS */}
        {currentSection === 'calendario' && (
          <div className="space-y-6">
            
            {/* Header controls */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <div>
                <span className="text-xs font-semibold text-slate-500">Agenda de Citas</span>
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-emerald-600" />
                  Calendario Médico y Estético
                </h3>
              </div>

              <div className="flex items-center gap-2.5 w-full sm:w-auto">
                <div className="bg-slate-100 p-1 rounded-lg border border-slate-200 flex gap-1">
                  <button className="px-3 py-1 bg-white rounded text-xs font-semibold shadow-sm text-slate-800">
                    Vista Semanal
                  </button>
                  <button className="px-3 py-1 rounded text-xs font-semibold text-slate-500 hover:text-slate-700">
                    Vista Mensual
                  </button>
                </div>
                <button
                  onClick={() => setShowAddCitaModal(true)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded shadow flex items-center gap-1 transition-all ml-auto"
                >
                  <Plus className="w-4 h-4" />
                  Nueva Cita
                </button>
              </div>
            </div>

            {/* Grid structure matching Page 11 screenshot */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border-slate-200 min-w-[700px]">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-center text-xs text-slate-700">
                      <th className="p-3 border-r border-slate-200 w-24">Hora</th>
                      {diasSemana.map((dia, idx) => (
                        <th key={idx} className="p-3 border-r border-slate-200 w-36 font-semibold">
                          <div className="text-[10px] text-slate-400 font-bold uppercase">{dia.nombre}</div>
                          <div className="text-sm font-extrabold text-slate-800 mt-0.5">{dia.numero}</div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {horasFiltro.map((horaSlot, hIdx) => (
                      <tr key={hIdx} className="border-b border-slate-100 hover:bg-slate-50/30 transition-all h-20">
                        <td className="p-3 border-r border-slate-200 text-center font-bold text-xs text-slate-500 bg-slate-50/50">
                          {horaSlot}
                        </td>
                        
                        {diasSemana.map((dia, dIdx) => {
                          // Find scheduled appointments in this slot
                          const slotCita = citas.find(c => {
                            // simple hour match (e.g. 09:00, 10:00, or matching nearest)
                            const [hCita, mCita] = c.hora.split(':');
                            const [hSlot, mSlot] = horaSlot.split(':');
                            const hourMatch = hCita === hSlot && Math.abs(Number(mCita) - Number(mSlot)) < 30;
                            return c.fecha === dia.fecha && hourMatch;
                          });

                          let blockStyle = "bg-transparent hover:bg-emerald-50/10 cursor-pointer";
                          let labelColor = "text-slate-800";
                          let doctorLabel = "";
                          
                          if (slotCita) {
                            const p = pacientes.find(x => x.idPaciente === slotCita.idPaciente);
                            const doc = doctores.find(d => d.idDoctor === slotCita.idDoctor);
                            doctorLabel = doc ? doc.nombre.split(' ')[1] : "Estilista";
                            
                            if (slotCita.tipo === 'Medica') {
                              blockStyle = "bg-indigo-50 border-l-4 border-indigo-500 text-indigo-900 shadow-sm rounded-r-md m-1 p-2 h-[calc(100%-8px)] flex flex-col justify-between";
                              labelColor = "text-indigo-950";
                            } else {
                              blockStyle = "bg-emerald-50 border-l-4 border-emerald-500 text-emerald-900 shadow-sm rounded-r-md m-1 p-2 h-[calc(100%-8px)] flex flex-col justify-between";
                              labelColor = "text-emerald-950";
                            }
                          }

                          return (
                            <td 
                              key={dIdx} 
                              className="border-r border-slate-200 p-1 relative w-36 align-top"
                              onClick={() => slotCita && setSelectedCitaDetail(slotCita)}
                            >
                              {slotCita ? (
                                <div className={blockStyle}>
                                  <div>
                                    <div className={`text-[10px] font-extrabold ${labelColor} flex items-center gap-1`}>
                                      {pacientes.find(x => x.idPaciente === slotCita.idPaciente)?.especie === 'Canino' ? '🐶' : '🐱'} 
                                      {pacientes.find(x => x.idPaciente === slotCita.idPaciente)?.nombre}
                                    </div>
                                    <div className="text-[8px] text-slate-500 font-medium truncate mt-0.5">{slotCita.motivo}</div>
                                  </div>
                                  <div className="text-[8px] font-bold text-slate-400 mt-1 uppercase tracking-wider text-right">
                                    Dr. {doctorLabel}
                                  </div>
                                </div>
                              ) : (
                                <div 
                                  onClick={() => {
                                    setCHora(horaSlot);
                                    setCFecha(dia.fecha);
                                    setShowAddCitaModal(true);
                                  }}
                                  className="w-full h-full min-h-[48px] cursor-pointer group flex items-center justify-center"
                                >
                                  <span className="opacity-0 group-hover:opacity-100 text-emerald-600 bg-emerald-50 p-1 rounded-full text-[10px] font-bold transition-all">
                                    + Reservar
                                  </span>
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Simulated interactive calendar detail popup */}
            {selectedCitaDetail && (
              <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
                <div className="bg-white rounded-xl border border-slate-200 shadow-2xl p-6 max-w-md w-full space-y-6">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                    <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Ficha Detalle de Cita</span>
                    <button 
                      onClick={() => setSelectedCitaDetail(null)}
                      className="text-slate-400 hover:text-slate-600 font-bold"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100 font-extrabold">
                        {pacientes.find(x => x.idPaciente === selectedCitaDetail.idPaciente)?.especie === 'Canino' ? '🐶' : '🐱'}
                      </div>
                      <div>
                        <h4 className="text-sm font-extrabold text-slate-800">
                          {pacientes.find(x => x.idPaciente === selectedCitaDetail.idPaciente)?.nombre}
                        </h4>
                        <p className="text-xs text-slate-500">
                          Dueño: {propietarios.find(o => o.idPropietario === (pacientes.find(x => x.idPaciente === selectedCitaDetail.idPaciente)?.idPropietario))?.nombre}
                        </p>
                      </div>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-lg space-y-2 text-xs text-slate-600 border border-slate-100">
                      <div><span className="font-bold text-slate-700">Veterinario:</span> {doctores.find(d => d.idDoctor === selectedCitaDetail.idDoctor)?.nombre || "Atención Estética"}</div>
                      <div><span className="font-bold text-slate-700">Fecha Cita:</span> {selectedCitaDetail.fecha.split('-').reverse().join('/')}</div>
                      <div><span className="font-bold text-slate-700">Hora Pactada:</span> {selectedCitaDetail.hora} AM</div>
                      <div><span className="font-bold text-slate-700">Motivo:</span> {selectedCitaDetail.motivo}</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedCitaDetail(null)}
                      className="flex-1 py-1.5 text-xs font-bold text-slate-600 border border-slate-200 rounded hover:bg-slate-50"
                    >
                      Cerrar
                    </button>
                    <button
                      onClick={() => {
                        setCitas(prev => prev.filter(c => c.idCita !== selectedCitaDetail.idCita));
                        setSelectedCitaDetail(null);
                        alert("Cita cancelada correctamente en el sistema.");
                      }}
                      className="flex-1 py-1.5 text-xs font-bold bg-rose-600 text-white rounded hover:bg-rose-500 shadow"
                    >
                      Anular Cita
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

        {/* SECTION 4: SPA & ESTETICA */}
        {currentSection === 'estetica' && (
          <div className="space-y-6">
            
            {/* Aesthetics Catalog Page 12 Header */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                <Scissors className="text-emerald-600 w-4.5 h-4.5" />
                Catálogo de Servicios Estéticos y de Bienestar (Spa)
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Seleccione un servicio del menú de estética veterinaria Ambar para cargar el formulario de atención.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
                {servicios.map((s) => (
                  <div key={s.idServicio} className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex flex-col justify-between hover:border-emerald-300 hover:shadow-sm transition-all group">
                    <div>
                      <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-bold">
                        Duración: {s.duracionMinutos} min
                      </span>
                      <h4 className="text-xs font-extrabold text-slate-800 mt-2">{s.nombre}</h4>
                    </div>
                    <div className="flex items-center justify-between mt-4 border-t border-slate-200/50 pt-2.5">
                      <span className="text-sm font-extrabold text-emerald-600">${s.costo.toFixed(2)}</span>
                      <button
                        onClick={() => {
                          setEsteticaServiciosId([s.idServicio]);
                          setEsteticaDuracion(`${s.duracionMinutos} minutos`);
                          setEsteticaNotas(`Servicio de ${s.nombre} programado.`);
                        }}
                        className="px-2 py-1 bg-white border border-slate-200 group-hover:bg-emerald-600 group-hover:text-white rounded text-[10px] font-bold transition-all active:scale-95"
                      >
                        Seleccionar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Booking care and generating Invoice ticket */}
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              
              {/* Form Entry */}
              <div className="lg:col-span-3 bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
                <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider pb-2 border-b border-slate-100 flex items-center gap-1">
                  <FilePlus className="w-4 h-4 text-emerald-600" />
                  Registro de Atención Estética Realizada
                </h4>

                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-600">Seleccionar Paciente (Mascota)</label>
                    <select
                      value={esteticaPacienteId}
                      onChange={(e) => setEsteticaPacienteId(Number(e.target.value))}
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-emerald-500 outline-none bg-white"
                    >
                      {pacientes.map(p => (
                        <option key={p.idPaciente} value={p.idPaciente}>
                          {p.nombre} ({p.especie} - Prop: {propietarios.find(o => o.idPropietario === p.idPropietario)?.nombre})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-600">Servicio Realizado</label>
                    <div className="space-y-1 bg-slate-50 p-2.5 rounded border border-slate-100 max-h-36 overflow-y-auto">
                      {servicios.map(s => {
                        const isChecked = esteticaServiciosId.includes(s.idServicio);
                        return (
                          <label key={s.idServicio} className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer p-1 rounded hover:bg-slate-200/50">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {
                                if (isChecked) {
                                  if (esteticaServiciosId.length > 1) {
                                    setEsteticaServiciosId(prev => prev.filter(id => id !== s.idServicio));
                                  }
                                } else {
                                  setEsteticaServiciosId(prev => [...prev, s.idServicio]);
                                }
                              }}
                              className="accent-emerald-600"
                            />
                            <span>{s.nombre} - <b className="text-emerald-600">${s.costo.toFixed(2)}</b></span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-600">Duración Aproximada</label>
                    <input
                      type="text"
                      placeholder="Ej. 45 minutos"
                      value={esteticaDuracion}
                      onChange={(e) => setEsteticaDuracion(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-600">Notas Adicionales y Recomendaciones</label>
                    <textarea
                      rows={3}
                      value={esteticaNotas}
                      onChange={(e) => setEsteticaNotas(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-emerald-500 outline-none resize-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={registrarAtencionEstetica}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded shadow transition-all active:scale-95"
                    >
                      Generar Comprobante (Boleta de Pago)
                    </button>
                  </div>
                </div>
              </div>

              {/* Printable Ticket Receipt Simulation */}
              <div className="lg:col-span-2">
                {showTicket && ticketDetails ? (
                  <div className="bg-white border border-dashed border-slate-300 rounded-xl p-5 shadow-sm font-mono text-[11px] text-slate-700 relative overflow-hidden bg-gradient-to-b from-amber-50/10 to-transparent">
                    <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-emerald-500 to-indigo-500"></div>
                    
                    {/* Header */}
                    <div className="text-center space-y-1 pb-4 border-b border-dashed border-slate-200">
                      <span className="text-xs font-bold uppercase tracking-wider block">Clínica Veterinaria Ambar</span>
                      <p className="text-[9px] text-slate-500">
                        RUC: 20602702805<br />
                        S3, G25, Mz. O, Lt. 1 – Villa el Salvador<br />
                        Telf: (01) 287-4321
                      </p>
                    </div>

                    {/* Receipt Metadata */}
                    <div className="py-3 border-b border-dashed border-slate-200 space-y-1">
                      <div className="flex justify-between font-bold">
                        <span>BOLETA DE VENTA</span>
                        <span>{ticketDetails.idComprobante}</span>
                      </div>
                      <div className="flex justify-between text-slate-500 text-[9px]">
                        <span>Fecha: {ticketDetails.fecha}</span>
                        <span>Hora: {ticketDetails.hora}</span>
                      </div>
                    </div>

                    {/* Customer Info */}
                    <div className="py-3 border-b border-dashed border-slate-200 space-y-0.5 text-[9px] text-slate-600">
                      <div><b>Cliente:</b> {ticketDetails.cliente}</div>
                      <div><b>Telf:</b> {ticketDetails.telefono}</div>
                      <div><b>Paciente:</b> {ticketDetails.mascota}</div>
                      <div><b>Ubicación:</b> {ticketDetails.direccion}</div>
                    </div>

                    {/* Products details */}
                    <div className="py-4 space-y-2 text-[10px]">
                      <div className="flex justify-between font-bold text-slate-500 border-b pb-1 text-[9px]">
                        <span>DESCRIPCIÓN</span>
                        <span>IMPORTE</span>
                      </div>
                      {ticketDetails.servicios.map((s: any, idx: number) => (
                        <div key={idx} className="flex justify-between">
                          <span>{s.nombre} ({ticketDetails.duracion})</span>
                          <span>${s.costo.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    {/* Total billing block */}
                    <div className="border-t border-dashed border-slate-200 pt-3 space-y-1 text-right">
                      <div className="flex justify-between font-extrabold text-xs text-slate-800">
                        <span>TOTAL A PAGAR:</span>
                        <span className="text-emerald-600">${ticketDetails.total.toFixed(2)}</span>
                      </div>
                      <p className="text-[8px] text-slate-400 italic text-center pt-4">
                        ¡Gracias por confiar el cuidado de su mascota a Veterinaria Ambar!
                      </p>
                    </div>

                    {/* Fake action triggers */}
                    <div className="mt-4 flex gap-2 font-sans pt-3 border-t border-slate-100">
                      <button
                        onClick={() => {
                          alert("Impresora térmica detectada. Imprimiendo Boleta de Venta...");
                        }}
                        className="flex-1 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded flex items-center justify-center gap-1"
                      >
                        <Printer className="w-3 h-3" />
                        Imprimir Ticket
                      </button>
                      <button
                        onClick={() => {
                          setShowTicket(false);
                          alert("Comprobante registrado con éxito en base de datos.");
                        }}
                        className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold rounded flex items-center justify-center gap-1 shadow"
                      >
                        <Check className="w-3 h-3" />
                        Confirmar Pago
                      </button>
                    </div>

                  </div>
                ) : (
                  <div className="bg-slate-100 border-2 border-dashed border-slate-200 rounded-xl h-full min-h-[300px] flex flex-col items-center justify-center text-center p-6 text-slate-400">
                    <CreditCard className="w-8 h-8 text-slate-300 mb-2" />
                    <p className="text-xs font-bold text-slate-500">Comprobante Digital</p>
                    <p className="text-[10px] mt-1 text-slate-400 max-w-xs">
                      Al procesar el servicio, aquí aparecerá la boleta de venta con formato de ticket térmico para su facturación.
                    </p>
                  </div>
                )}
              </div>

            </div>

          </div>
        )}

      </div>

      {/* MODALS SECTION */}
      {/* 1. Modal New Patient */}
      {showAddPacienteModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xl p-6 max-w-md w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-800 border-b pb-2">Registrar Nueva Mascota</h3>
            
            <form onSubmit={registrarPaciente} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-600">Nombre de la Mascota *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Max"
                  value={mNombre}
                  onChange={(e) => setMNombre(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-600">Especie *</label>
                  <select
                    value={mEspecie}
                    onChange={(e) => setMEspecie(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded outline-none bg-white"
                  >
                    <option value="Canino">🐶 Canino</option>
                    <option value="Felino">🐱 Felino</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-600">Raza *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. Labrador"
                    value={mRaza}
                    onChange={(e) => setMRaza(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-600">Edad (Años)</label>
                  <input
                    type="number"
                    min="0"
                    value={mEdad}
                    onChange={(e) => setMEdad(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-600">F. Nacimiento</label>
                  <input
                    type="date"
                    value={mNacimiento}
                    onChange={(e) => setMNacimiento(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-600">Propietario / Dueño *</label>
                <div className="flex gap-1.5">
                  <select
                    value={mPropietarioId}
                    onChange={(e) => setMPropietarioId(Number(e.target.value))}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded outline-none bg-white"
                  >
                    {propietarios.map(o => (
                      <option key={o.idPropietario} value={o.idPropietario}>
                        {o.nombre} ({o.telefono})
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddPacienteModal(false);
                      setCurrentSection('propietario');
                    }}
                    className="px-3 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded font-bold"
                    title="Crear nuevo propietario"
                  >
                    + Nuevo
                  </button>
                </div>
              </div>

              <div className="flex gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowAddPacienteModal(false)}
                  className="flex-1 py-1.5 text-slate-600 border border-slate-200 rounded font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-1.5 bg-emerald-600 text-white rounded font-bold hover:bg-emerald-500 shadow"
                >
                  Registrar Mascota
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. Modal New Clinical Record Entry */}
      {showAddHistorialModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xl p-6 max-w-md w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-800 border-b pb-2 flex items-center gap-1">
              <FilePlus className="w-4 h-4 text-emerald-600" />
              Añadir Entrada al Historial Clínico
            </h3>

            <form onSubmit={registrarHistorial} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-600">Paciente</label>
                <input
                  type="text"
                  disabled
                  value={selectedPaciente?.nombre}
                  className="w-full px-3 py-2 border border-slate-200 rounded bg-slate-50 text-slate-500 font-bold cursor-not-allowed"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-600">Diagnóstico *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Dermatitis atópica, Faringitis leve"
                  value={nuevaEntradaDiag}
                  onChange={(e) => setNuevaEntradaDiag(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-600">Tratamiento Realizado y Recomendaciones *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Ej. Recetar jarabe antiinflamatorio 2ml c/12h por 5 días. Programar baño antiséptico."
                  value={nuevaEntradaTrat}
                  onChange={(e) => setNuevaEntradaTrat(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded outline-none resize-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="flex gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowAddHistorialModal(false)}
                  className="flex-1 py-1.5 text-slate-600 border border-slate-200 rounded font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-1.5 bg-emerald-600 text-white rounded font-bold hover:bg-emerald-500 shadow"
                >
                  Añadir al Historial
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. Modal New Appointment */}
      {showAddCitaModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xl p-6 max-w-md w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-800 border-b pb-2">Programar Nueva Cita</h3>

            <form onSubmit={registrarCita} className="space-y-3.5 text-xs">
              
              <div className="space-y-1">
                <label className="font-bold text-slate-600">Seleccionar Paciente *</label>
                <select
                  value={cPacienteId}
                  onChange={(e) => setCPacienteId(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded outline-none bg-white"
                >
                  {pacientes.map(p => (
                    <option key={p.idPaciente} value={p.idPaciente}>
                      {p.nombre} ({p.especie})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-600">Tipo de Servicio *</label>
                  <select
                    value={cTipo}
                    onChange={(e) => setCTipo(e.target.value as 'Medica' | 'Estetica')}
                    className="w-full px-3 py-2 border border-slate-300 rounded outline-none bg-white"
                  >
                    <option value="Medica">🩺 Consulta Médica</option>
                    <option value="Estetica">✂️ Estética / Spa</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-600">Veterinario Asignado</label>
                  <select
                    value={cDoctorId}
                    disabled={cTipo === 'Estetica'}
                    onChange={(e) => setCDoctorId(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded outline-none bg-white disabled:bg-slate-50 disabled:text-slate-400"
                  >
                    {doctores.map(d => (
                      <option key={d.idDoctor} value={d.idDoctor}>
                        {d.nombre}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-600">Fecha Pactada *</label>
                  <input
                    type="date"
                    required
                    value={cFecha}
                    onChange={(e) => setCFecha(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-600">Hora Pactada *</label>
                  <select
                    value={cHora}
                    onChange={(e) => setCHora(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded outline-none bg-white"
                  >
                    {horasFiltro.map((h, idx) => (
                      <option key={idx} value={h}>{h} AM</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-600">Motivo / Descripción de la Cita *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Vacuna Quintuple de control o Baño completo"
                  value={cMotivo}
                  onChange={(e) => setCMotivo(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded outline-none"
                />
              </div>

              <div className="flex gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowAddCitaModal(false)}
                  className="flex-1 py-1.5 text-slate-600 border border-slate-200 rounded font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-1.5 bg-emerald-600 text-white rounded font-bold hover:bg-emerald-500 shadow"
                >
                  Confirmar Reserva
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
