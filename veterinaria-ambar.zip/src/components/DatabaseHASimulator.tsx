import React, { useState, useEffect } from 'react';
import { 
  Database, Server, Cpu, Layers, Activity, Terminal, Code, Copy, Check, 
  Settings, AlertCircle, Play, Zap, CheckCircle2, Shield, RefreshCw, Plus, Trash2, ArrowRight
} from 'lucide-react';
import { Propietario, Paciente, Doctor, HistorialClinico, CitaMedica, EsteticoServicio } from '../types';
import { MYSQL_SCHEMA_SQL, PHP_CONNECTION_CODE } from '../data/mockData';

interface DatabaseHASimulatorProps {
  propietarios: Propietario[];
  pacientes: Paciente[];
  doctores: Doctor[];
  historialClinico: HistorialClinico[];
  citas: CitaMedica[];
  servicios: EsteticoServicio[];
  setPropietarios: React.Dispatch<React.SetStateAction<Propietario[]>>;
  setPacientes: React.Dispatch<React.SetStateAction<Paciente[]>>;
  setDoctores: React.Dispatch<React.SetStateAction<Doctor[]>>;
}

export default function DatabaseHASimulator({
  propietarios,
  pacientes,
  doctores,
  historialClinico,
  citas,
  servicios,
  setPropietarios,
  setPacientes,
  setDoctores
}: DatabaseHASimulatorProps) {
  const [activeTab, setActiveTab] = useState<'erd' | 'ha_lab' | 'sql_console' | 'code_exports'>('ha_lab');
  
  // HA Lab States
  const [webNodesCount, setWebNodesCount] = useState<number>(2);
  const [trafficRate, setTrafficRate] = useState<number>(30); // req/sec
  const [masterStatus, setMasterStatus] = useState<'healthy' | 'crashed' | 'failover'>('healthy');
  const [replica1Status, setReplica1Status] = useState<'replica' | 'promoting' | 'new_master'>('replica');
  const [replica2Status, setReplica2Status] = useState<'replica' | 'healthy'>('replica');
  const [activeConnections, setActiveConnections] = useState<number>(12);
  const [responseTimeMs, setResponseTimeMs] = useState<number>(18);
  const [logs, setLogs] = useState<string[]>([
    "[Sistema] Cluster iniciado. Master DB en puerto 3306. Réplicas conectadas por canal de replicación asíncrona.",
    "[LoadBalancer] Distribuyendo tráfico Round-Robin entre las instancias de servidor de aplicaciones PHP."
  ]);
  const [isGeneratingTraffic, setIsGeneratingTraffic] = useState<boolean>(false);

  // SQL Console States
  const [sqlQuery, setSqlQuery] = useState<string>("SELECT * FROM propietario;");
  const [sqlResults, setSqlResults] = useState<{ headers: string[]; rows: any[][] } | null>(null);
  const [sqlError, setSqlError] = useState<string | null>(null);
  const [sqlSuccessMessage, setSqlSuccessMessage] = useState<string | null>(null);
  const [copiadoCode, setCopiadoCode] = useState<boolean>(false);
  const [selectedCodeTab, setSelectedCodeTab] = useState<'mysql' | 'php'>('mysql');

  // Trigger copy feedback
  const copiarAlPortapapeles = (texto: string) => {
    navigator.clipboard.writeText(texto);
    setCopiadoCode(true);
    setTimeout(() => setCopiadoCode(false), 2000);
  };

  // Add a log entry
  const addLog = (msg: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] ${msg}`, ...prev.slice(0, 30)]);
  };

  // Simulate Traffic loop
  useEffect(() => {
    let interval: any = null;
    if (isGeneratingTraffic) {
      interval = setInterval(() => {
        // Calculate random variations
        const activeConn = Math.floor(trafficRate * 0.4 + Math.random() * 5);
        setActiveConnections(activeConn);
        
        let baseResponse = 8; // base ms
        // response time increases with nodes deficit or db issues
        if (webNodesCount < 2) baseResponse += 15;
        if (trafficRate > 80) baseResponse += 12;
        if (masterStatus === 'crashed') baseResponse += 80; // timeout retries
        if (masterStatus === 'failover') baseResponse += 250; // failover lag
        
        const currentResp = Math.floor(baseResponse + Math.random() * 6);
        setResponseTimeMs(currentResp);

        // Add periodic logs
        const rand = Math.random();
        if (rand < 0.25) {
          const randomMethod = Math.random() > 0.4 ? 'GET' : 'POST';
          if (randomMethod === 'GET') {
            const routes = ['/api/pacientes.php', '/api/servicios.php', '/api/citas.php'];
            const chosenRoute = routes[Math.floor(Math.random() * routes.length)];
            const replicaId = Math.random() > 0.5 ? 'Replica 1' : 'Replica 2';
            
            if (masterStatus === 'healthy') {
              addLog(`[AppNode-${Math.floor(Math.random() * webNodesCount) + 1}] Consulta de lectura procesada desde ${replicaId}: SELECT * FROM ...`);
            } else if (masterStatus === 'crashed') {
              addLog(`[AppNode-${Math.floor(Math.random() * webNodesCount) + 1}] Error de lectura: No hay réplicas disponibles. Intentando fallback...`);
            } else if (masterStatus === 'failover') {
              addLog(`[AppNode-${Math.floor(Math.random() * webNodesCount) + 1}] Reintentando consulta SELECT sobre el nuevo nodo Master promovido.`);
            }
          } else {
            addLog(`[AppNode-${Math.floor(Math.random() * webNodesCount) + 1}] Petición de escritura procesada en Master: INSERT INTO cita_medica ...`);
          }
        }
      }, 1500);
    } else {
      setActiveConnections(0);
      setResponseTimeMs(12);
    }
    return () => clearInterval(interval);
  }, [isGeneratingTraffic, trafficRate, webNodesCount, masterStatus]);

  // Handle crash simulation
  const handleCrashMaster = () => {
    if (masterStatus !== 'healthy') return;
    
    setMasterStatus('crashed');
    setIsGeneratingTraffic(true); // force traffic to show effect
    addLog("🚨 ALERTA: ¡El Servidor MySQL Master ha dejado de responder!");
    addLog("⚠️ El monitor de salud (Health Check) detecta inactividad en db-master.veterinaria-ambar.internal.");
    addLog("⏳ Iniciando temporizador de failover (Grace period: 3 segundos)...");

    setTimeout(() => {
      setMasterStatus('failover');
      setReplica1Status('promoting');
      addLog("🔄 PROCESO DE FAILOVER INICIADO:");
      addLog("   1. Desconectando réplicas de la sincronización con el Master caído.");
      addLog("   2. Verificando que db-replica-1 tenga las últimas transacciones (binlog sync).");
      addLog("   3. Ejecutando comando de promoción: 'STOP SLAVE; RESET MASTER;'.");
      
      setTimeout(() => {
        setMasterStatus('failover');
        setReplica1Status('new_master');
        addLog("✅ EXITO: db-replica-1 ha sido promovido exitosamente a NUEVO MASTER.");
        addLog("🔄 Actualizando DNS interno y configuraciones del Load Balancer.");
        addLog("ℹ️ db-replica-2 configurado ahora como esclavo de db-replica-1.");
        addLog("🚀 Tráfico de escritura y lectura reestablecido al 100%.");
      }, 3000);
    }, 3000);
  };

  // Handle restore master
  const handleRestoreMaster = () => {
    setMasterStatus('healthy');
    setReplica1Status('replica');
    setReplica2Status('replica');
    addLog("🏥 REPARACIÓN: Servidor db-master original ha sido restaurado.");
    addLog("🔄 Sincronizando datos atrasados (Catching up log sequence numbers)...");
    addLog("✅ db-master reasume el rol de Master Principal. Las réplicas vuelven a modo de lectura.");
  };

  // Simulated SQL query compiler
  const executeSQL = (queryStr: string) => {
    setSqlError(null);
    setSqlSuccessMessage(null);
    setSqlResults(null);

    const cleanQuery = queryStr.trim().replace(/\s+/g, ' ').toLowerCase();

    if (!cleanQuery) {
      setSqlError("Error de sintaxis: La consulta no puede estar vacía.");
      return;
    }

    try {
      // 1. SELECT queries
      if (cleanQuery.startsWith("select")) {
        if (cleanQuery.includes("from propietario")) {
          const headers = ["idPropietario", "nombre", "telefono", "email", "direccion"];
          const rows = propietarios.map(p => [p.idPropietario, p.nombre, p.telefono, p.email, p.direccion]);
          setSqlResults({ headers, rows });
          setSqlSuccessMessage(`Consulta SELECT completada con éxito. Se encontraron ${propietarios.length} registros.`);
          addLog("Consola SQL: SELECT * FROM propietario ejecutado con éxito.");
        } 
        else if (cleanQuery.includes("from paciente")) {
          // Check for join or filter
          if (cleanQuery.includes("join propietario")) {
            const headers = ["Paciente", "Especie", "Raza", "Dueño", "Email"];
            const rows = pacientes.map(p => {
              const prop = propietarios.find(o => o.idPropietario === p.idPropietario);
              return [p.nombre, p.especie, p.raza, prop ? prop.nombre : "Sin dueño", prop ? prop.email : "-"];
            });
            setSqlResults({ headers, rows });
            setSqlSuccessMessage(`Consulta JOIN completada. ${pacientes.length} registros cruzados.`);
            addLog("Consola SQL: SELECT con JOIN ejecutado.");
          } else {
            const headers = ["idPaciente", "nombre", "especie", "raza", "edad", "idPropietario"];
            const rows = pacientes.map(p => [p.idPaciente, p.nombre, p.especie, p.raza, p.edad, p.idPropietario]);
            setSqlResults({ headers, rows });
            setSqlSuccessMessage(`Consulta SELECT completada con éxito. Se encontraron ${pacientes.length} registros.`);
            addLog("Consola SQL: SELECT * FROM paciente ejecutado.");
          }
        } 
        else if (cleanQuery.includes("from doctor")) {
          const headers = ["idDoctor", "nombre", "especialidad"];
          const rows = doctores.map(d => [d.idDoctor, d.nombre, d.especialidad]);
          setSqlResults({ headers, rows });
          setSqlSuccessMessage(`Consulta SELECT completada con éxito. Se encontraron ${doctores.length} registros.`);
          addLog("Consola SQL: SELECT * FROM doctor ejecutado.");
        } 
        else if (cleanQuery.includes("from historial_clinico")) {
          const headers = ["idHistorial", "idPaciente", "fecha", "diagnostico", "tratamiento"];
          const rows = historialClinico.map(h => [h.idHistorial, h.idPaciente, h.fecha, h.diagnostico, h.tratamiento]);
          setSqlResults({ headers, rows });
          setSqlSuccessMessage(`Consulta SELECT completada con éxito.`);
        } 
        else if (cleanQuery.includes("from cita_medica") || cleanQuery.includes("from agenda")) {
          const headers = ["idCita", "idPaciente", "fecha", "hora", "motivo", "tipo"];
          const rows = citas.map(c => [c.idCita, c.idPaciente, c.fecha, c.hora, c.motivo, c.tipo]);
          setSqlResults({ headers, rows });
          setSqlSuccessMessage(`Consulta SELECT completada con éxito. Se encontraron ${citas.length} registros.`);
        } 
        else if (cleanQuery.includes("from estetico_servicio")) {
          const headers = ["idServicio", "nombre", "costo", "duracionMinutos"];
          const rows = servicios.map(s => [s.idServicio, s.nombre, `$${s.costo.toFixed(2)}`, `${s.duracionMinutos} min`]);
          setSqlResults({ headers, rows });
          setSqlSuccessMessage(`Consulta SELECT completada con éxito.`);
        } 
        else {
          setSqlError("La consulta SELECT es válida, pero la tabla no está en el esquema simulado de Veterinaria Ambar.");
        }
      } 
      // 2. INSERT queries
      else if (cleanQuery.startsWith("insert")) {
        if (cleanQuery.includes("into doctor")) {
          // Parse values insert into doctor (nombre, especialidad) values ('Dr. Lucas Lima', 'Oftalmología')
          const regex = /values\s*\(\s*'(.*?)'\s*,\s*'(.*?)'\s*\)/i;
          const match = queryStr.match(regex);
          if (match && match.length >= 3) {
            const nuevoDoc: Doctor = {
              idDoctor: doctores.length + 1,
              nombre: match[1],
              especialidad: match[2]
            };
            setDoctores(prev => [...prev, nuevoDoc]);
            setSqlSuccessMessage(`Éxito: Fila insertada en tabla [doctor]. ID Generado: ${nuevoDoc.idDoctor}.`);
            addLog(`Consola SQL: INSERT exitoso en tabla 'doctor' para [${nuevoDoc.nombre}]`);
          } else {
            setSqlError("Sintaxis de INSERT inválida. Ejemplo correcto: INSERT INTO doctor (nombre, especialidad) VALUES ('Dr. Lucas Lima', 'Oftalmología');");
          }
        } 
        else if (cleanQuery.includes("into propietario")) {
          const regex = /values\s*\(\s*'(.*?)'\s*,\s*'(.*?)'\s*,\s*'(.*?)'\s*,\s*'(.*?)'\s*\)/i;
          const match = queryStr.match(regex);
          if (match && match.length >= 5) {
            const nuevoProp: Propietario = {
              idPropietario: propietarios.length + 1,
              nombre: match[1],
              telefono: match[2],
              email: match[3],
              direccion: match[4]
            };
            setPropietarios(prev => [...prev, nuevoProp]);
            setSqlSuccessMessage(`Éxito: Propietario registrado en la base de datos MySQL simulada. ID: ${nuevoProp.idPropietario}`);
            addLog(`Consola SQL: INSERT exitoso en tabla 'propietario' para [${nuevoProp.nombre}]`);
          } else {
            setSqlError("Sintaxis incorrecta. Ejemplo: INSERT INTO propietario (nombre, telefono, email, direccion) VALUES ('Maria Lopez', '999888777', 'maria@email.com', 'Calle Real 456');");
          }
        } 
        else {
          setSqlError("Sintaxis INSERT soportada en esta consola interactiva únicamente para las tablas 'doctor' o 'propietario' con fines educativos.");
        }
      } 
      // 3. Simple errors
      else {
        setSqlError("Comando SQL no implementado en este sandbox interactivo. Solo se admiten consultas de tipo SELECT o INSERT con el formato estándar de SQL.");
      }
    } catch (e) {
      setSqlError("Error al procesar la sentencia SQL. Asegúrate de que las comillas y la sintaxis sean correctas para MySQL 8.0.");
    }
  };

  return (
    <div className="bg-slate-900 text-slate-100 rounded-xl border border-slate-800 shadow-2xl overflow-hidden font-sans">
      
      {/* Upper Module Menu */}
      <div className="bg-slate-950 border-b border-slate-800 px-6 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-indigo-500/20 text-indigo-400 rounded-lg">
              <Database className="w-5 h-5" />
            </span>
            <h2 className="text-lg font-semibold tracking-tight">Laboratorio de Base de Datos y Alta Disponibilidad</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Módulo académico interactivo de MySQL, PHP y topología de servidores resilientes para el proyecto Clínica Veterinaria Ambar.
          </p>
        </div>

        {/* Action Tabs */}
        <div className="flex flex-wrap gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 self-start md:self-auto">
          <button
            onClick={() => setActiveTab('ha_lab')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${activeTab === 'ha_lab' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Activity className="w-3.5 h-3.5 inline mr-1" />
            Alta Disponibilidad (HA)
          </button>
          <button
            onClick={() => setActiveTab('erd')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${activeTab === 'erd' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Layers className="w-3.5 h-3.5 inline mr-1" />
            Diagrama Entidad-Relación
          </button>
          <button
            onClick={() => setActiveTab('sql_console')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${activeTab === 'sql_console' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Terminal className="w-3.5 h-3.5 inline mr-1" />
            Consola SQL Interactiva
          </button>
          <button
            onClick={() => setActiveTab('code_exports')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${activeTab === 'code_exports' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Code className="w-3.5 h-3.5 inline mr-1" />
            Código PHP y SQL
          </button>
        </div>
      </div>

      {/* Main Tab Contents */}
      <div className="p-6">
        
        {/* TAB 1: HIGH AVAILABILITY & SCALABILITY LAB */}
        {activeTab === 'ha_lab' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* HA Topology Canvas */}
            <div className="lg:col-span-2 space-y-6">
              
              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-indigo-400" />
                    Topología del Clúster de Producción
                  </h3>
                  <span className="text-[10px] bg-slate-800 border border-slate-700 text-indigo-400 px-2 py-0.5 rounded-full">
                    Soporta 10,000+ Usuarios Activos
                  </span>
                </div>

                {/* Simulated Topology Graph */}
                <div className="flex flex-col gap-6 items-center py-4 relative">
                  
                  {/* Row 1: Users & Load Balancer */}
                  <div className="flex justify-around w-full relative">
                    <div className="flex flex-col items-center bg-slate-900 border border-slate-800 px-4 py-3 rounded-lg text-center w-36">
                      <Zap className="w-5 h-5 text-yellow-400 animate-pulse mb-1" />
                      <span className="text-xs font-semibold text-slate-200">Tráfico Externo</span>
                      <span className="text-[10px] text-slate-400 mt-0.5">{trafficRate} req/seg</span>
                    </div>

                    <div className="flex flex-col items-center justify-center p-3 bg-gradient-to-br from-indigo-900/60 to-slate-950 border border-indigo-700/50 rounded-xl w-40 shadow-lg shadow-indigo-950/20">
                      <Settings className="w-6 h-6 text-indigo-400 animate-spin-slow mb-1" />
                      <span className="text-xs font-semibold text-indigo-300">Nginx Load Balancer</span>
                      <span className="text-[9px] text-slate-400 mt-0.5">Proxy Reverso & SSL</span>
                    </div>
                  </div>

                  {/* Connector lines (CSS vectors) */}
                  <div className="h-4 border-l border-dashed border-indigo-500/40"></div>

                  {/* Row 2: Scalable Web/Application Layer (PHP FPM) */}
                  <div className="space-y-2 w-full">
                    <div className="text-center text-[10px] text-slate-400 font-medium">Capa de Servidores PHP (Nodos de Cómputo)</div>
                    <div className="flex flex-wrap justify-center gap-4">
                      {Array.from({ length: webNodesCount }).map((_, idx) => (
                        <div key={idx} className="flex items-center gap-2 bg-slate-900 border border-indigo-900/30 px-3 py-2 rounded-lg relative">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping absolute -top-1 -right-1"></span>
                          <span className="w-2 h-2 rounded-full bg-emerald-500 absolute -top-1 -right-1"></span>
                          <Server className="w-4 h-4 text-indigo-400" />
                          <div className="text-left">
                            <div className="text-[10px] font-bold text-slate-200">php-node-{idx+1}</div>
                            <div className="text-[8px] text-slate-400">RAM: {(15 + Math.random() * 8).toFixed(0)}% | CPU: {(12 + Math.random() * 10).toFixed(0)}%</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Connector lines */}
                  <div className="h-4 border-l border-dashed border-indigo-500/40"></div>

                  {/* Row 3: Cache Layer (Redis) */}
                  <div className="flex justify-center w-full">
                    <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-rose-400" />
                      <span className="text-[10px] font-semibold text-slate-300">Redis Cache In-Memory (Sesiones & Catálogos)</span>
                    </div>
                  </div>

                  {/* Connector lines */}
                  <div className="h-4 border-l border-dashed border-indigo-500/40"></div>

                  {/* Row 4: High Availability MySQL Database Layer */}
                  <div className="w-full space-y-2">
                    <div className="text-center text-[10px] text-slate-400 font-medium">Capa de Datos de Alta Disponibilidad (MySQL Cluster Master-Slave)</div>
                    
                    <div className="flex flex-col md:flex-row justify-center items-center gap-6">
                      
                      {/* Master Primary Node */}
                      <div className={`p-4 rounded-xl border w-48 text-center transition-all duration-300 ${
                        masterStatus === 'healthy' ? 'bg-slate-900 border-emerald-500/50 text-emerald-300 shadow-md shadow-emerald-950/20' :
                        masterStatus === 'failover' ? 'bg-slate-900 border-yellow-500/50 text-yellow-300 animate-pulse' :
                        'bg-red-950/40 border-red-500/70 text-red-300 animate-bounce'
                      }`}>
                        <div className="flex justify-between items-center mb-2">
                          <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-bold ${
                            masterStatus === 'healthy' ? 'bg-emerald-500/20 text-emerald-400' :
                            masterStatus === 'failover' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {masterStatus === 'healthy' ? 'MASTER' : masterStatus === 'failover' ? 'PROMOCIÓN' : 'CAÍDO'}
                          </span>
                          <Database className="w-4 h-4" />
                        </div>
                        <div className="text-xs font-bold text-slate-100">db-master</div>
                        <div className="text-[9px] text-slate-400 mt-1">Host de Escrituras (Write)</div>
                        <div className="text-[9px] font-mono mt-1 text-slate-300">
                          {masterStatus === 'healthy' ? 'Status: ONLINE' : masterStatus === 'failover' ? 'PROCESANDO FAILOVER' : 'OFFLINE (CRASH)'}
                        </div>
                      </div>

                      {/* Asynchronous replication channel indicator */}
                      <div className="flex flex-col items-center">
                        <div className="flex items-center gap-1 text-[9px] font-semibold text-indigo-400">
                          <span>Replicación Asíncrona (BinLog)</span>
                          <ArrowRight className="w-3 h-3 text-indigo-400" />
                        </div>
                        <div className="w-16 h-1 bg-slate-800 border-b border-indigo-500/30 rounded"></div>
                      </div>

                      {/* Replica Node 1 (Failover candidate) */}
                      <div className={`p-4 rounded-xl border w-48 text-center transition-all duration-300 ${
                        replica1Status === 'new_master' ? 'bg-slate-900 border-indigo-500/50 text-indigo-300' :
                        replica1Status === 'promoting' ? 'bg-yellow-950/40 border-yellow-500/50 text-yellow-300 animate-pulse' :
                        'bg-slate-900 border-slate-800 text-slate-300'
                      }`}>
                        <div className="flex justify-between items-center mb-2">
                          <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-bold bg-indigo-500/20 text-indigo-400`}>
                            {replica1Status === 'new_master' ? 'NUEVO MASTER' : replica1Status === 'promoting' ? 'PROMOVIENDO' : 'REPLICA 1'}
                          </span>
                          <Database className="w-4 h-4" />
                        </div>
                        <div className="text-xs font-bold text-slate-100">db-replica-1</div>
                        <div className="text-[9px] text-slate-400 mt-1">Host de Lecturas (Read)</div>
                        <div className="text-[9px] font-mono mt-1 text-slate-300">
                          {replica1Status === 'new_master' ? 'Status: ONLINE' : replica1Status === 'promoting' ? 'PROMOCIÓN ACTIVADA' : 'Sincronizado: OK'}
                        </div>
                      </div>

                    </div>
                  </div>

                </div>
              </div>

              {/* Lab Logs Console */}
              <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-xs font-bold text-indigo-400 flex items-center gap-1">
                    <Terminal className="w-3.5 h-3.5" />
                    Bitácora del Servidor y Clúster de Datos (Logs)
                  </span>
                  <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
                </div>
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 h-44 overflow-y-auto text-[10px] space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                  {logs.map((log, i) => (
                    <div key={i} className={`p-1 rounded ${
                      log.includes("ALERTA") || log.includes("Error") ? 'bg-red-950/30 text-red-400 border-l-2 border-red-500 pl-1.5' :
                      log.includes("PROCESO") || log.includes("failover") ? 'bg-yellow-950/20 text-yellow-400 border-l-2 border-yellow-500 pl-1.5' :
                      log.includes("ÉXITO") || log.includes("EXITO") || log.includes("promovido") ? 'bg-emerald-950/20 text-emerald-400 border-l-2 border-emerald-500 pl-1.5' :
                      'text-slate-300'
                    }`}>
                      {log}
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Interactive Control Panel */}
            <div className="bg-slate-950 rounded-xl border border-slate-800 p-5 space-y-6">
              <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-1.5">
                <Settings className="w-4 h-4 text-indigo-400" />
                Panel de Control del Laboratorio
              </h3>

              {/* 1. Traffic simulation toggle */}
              <div className="space-y-2 p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-slate-200">Generador de Tráfico Activo</span>
                  <button
                    onClick={() => setIsGeneratingTraffic(!isGeneratingTraffic)}
                    className={`px-3 py-1 rounded text-xs font-bold transition-all ${
                      isGeneratingTraffic ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    {isGeneratingTraffic ? 'Detener' : 'Iniciar'}
                  </button>
                </div>
                <p className="text-[10px] text-slate-400">
                  Simula peticiones simultáneas de usuarios registrando mascotas o reservando citas.
                </p>
                {isGeneratingTraffic && (
                  <div className="space-y-1.5 pt-2">
                    <label className="text-[10px] text-slate-300 flex justify-between">
                      <span>Intensidad de Tráfico:</span>
                      <span className="font-bold text-indigo-400">{trafficRate} req/seg</span>
                    </label>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={trafficRate}
                      onChange={(e) => setTrafficRate(Number(e.target.value))}
                      className="w-full accent-indigo-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                )}
              </div>

              {/* 2. Compute scaling */}
              <div className="space-y-2 p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                <label className="text-xs font-bold text-slate-200 flex justify-between">
                  <span>Escalar Nodos PHP:</span>
                  <span className="text-indigo-400 font-bold">{webNodesCount} Instancias</span>
                </label>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      if (webNodesCount > 1) {
                        setWebNodesCount(prev => prev - 1);
                        addLog(`[Escalabilidad] Escalamiento hacia abajo: Eliminado nodo php-node-${webNodesCount}.`);
                      }
                    }}
                    className="flex-1 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded border border-slate-700"
                  >
                    Reducir (-1)
                  </button>
                  <button
                    onClick={() => {
                      if (webNodesCount < 5) {
                        setWebNodesCount(prev => prev + 1);
                        addLog(`[Escalabilidad] Escalamiento horizontal hacia arriba: Iniciando php-node-${webNodesCount + 1} para tolerar más carga.`);
                      }
                    }}
                    className="flex-1 py-1 text-xs bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded"
                  >
                    Añadir (+1)
                  </button>
                </div>
                <p className="text-[10px] text-slate-400">
                  Aumenta el número de servidores PHP para balancear el tráfico. Evita la sobrecarga de CPU.
                </p>
              </div>

              {/* 3. Failover Trigger */}
              <div className="space-y-2 p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                <span className="text-xs font-bold text-slate-200 block">Inyección de Fallas en DB</span>
                {masterStatus === 'healthy' ? (
                  <button
                    onClick={handleCrashMaster}
                    className="w-full py-2 bg-red-900 hover:bg-red-800 border border-red-700/50 text-red-200 text-xs font-bold rounded flex items-center justify-center gap-1"
                  >
                    <AlertCircle className="w-3.5 h-3.5" />
                    Simular Caída de MySQL Master
                  </button>
                ) : (
                  <button
                    onClick={handleRestoreMaster}
                    className="w-full py-2 bg-emerald-950 border border-emerald-700 hover:bg-emerald-900 text-emerald-200 text-xs font-bold rounded flex items-center justify-center gap-1"
                  >
                    <RefreshCw className="w-3.5 h-3.5 animate-spin-slow" />
                    Restaurar Nodo Master Original
                  </button>
                )}
                <p className="text-[10px] text-slate-400">
                  Prueba la resistencia del sistema. Al tumbar el Master, se activará el script de promoción automática de réplica a Master sin pérdida de servicio.
                </p>
              </div>

              {/* 4. Real-time Metrics */}
              <div className="space-y-2.5 pt-4 border-t border-slate-800">
                <div className="text-xs font-bold text-slate-300">Métricas de Resiliencia en Vivo</div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-900 p-2.5 rounded-lg text-center border border-slate-800">
                    <div className="text-[9px] text-slate-400 uppercase font-semibold">Tasa de Conexiones</div>
                    <div className="text-base font-extrabold text-indigo-400 mt-1">{activeConnections} / 250</div>
                  </div>
                  <div className="bg-slate-900 p-2.5 rounded-lg text-center border border-slate-800">
                    <div className="text-[9px] text-slate-400 uppercase font-semibold">Tiempo Respuesta</div>
                    <div className="text-base font-extrabold text-emerald-400 mt-1">{responseTimeMs} ms</div>
                  </div>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 2: ENTITY-RELATIONSHIP DIAGRAM (ERD) */}
        {activeTab === 'erd' && (
          <div className="space-y-6">
            <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-indigo-400" />
                  Modelo Físico Relacional de la Base de Datos MySQL
                </h3>
                <span className="text-xs text-slate-400 font-mono">Motor de Almacenamiento: InnoDB</span>
              </div>
              
              <p className="text-xs text-slate-300 leading-relaxed">
                Este diagrama físico detalla las tablas estructuradas para la <b>Clínica Veterinaria Ambar</b> con sus respectivas llaves primarias (PK), llaves foráneas (FK), tipos de datos y relaciones cardinales. Su diseño incluye índices estratégicos para agilizar las consultas de búsqueda de historiales clínicos y citas médicas.
              </p>

              {/* Graphical representation of tables */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
                
                {/* Table: Propietario */}
                <div className="bg-slate-900 rounded-lg border border-indigo-500/30 overflow-hidden shadow-lg shadow-indigo-950/10">
                  <div className="bg-indigo-900/40 px-3 py-2 border-b border-indigo-500/30 flex justify-between items-center">
                    <span className="text-xs font-bold text-indigo-200">propietario</span>
                    <span className="text-[9px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded font-mono">1:N a Paciente</span>
                  </div>
                  <div className="p-3 font-mono text-[10px] space-y-1.5">
                    <div className="flex justify-between border-b border-slate-800/50 pb-1 text-slate-200">
                      <span className="font-bold text-yellow-400">🔑 idPropietario</span>
                      <span className="text-slate-400 font-semibold">INT AUTO_INC (PK)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>nombre</span>
                      <span className="text-slate-500">VARCHAR(150)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>telefono</span>
                      <span className="text-slate-500">VARCHAR(20)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>email</span>
                      <span className="text-slate-500">VARCHAR(100)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>direccion</span>
                      <span className="text-slate-500">TEXT</span>
                    </div>
                    <div className="text-[8px] text-indigo-400/80 mt-2 font-sans italic">
                      🔍 Indexado por nombre para búsquedas instantáneas en recepción.
                    </div>
                  </div>
                </div>

                {/* Table: Paciente */}
                <div className="bg-slate-900 rounded-lg border border-emerald-500/30 overflow-hidden shadow-lg">
                  <div className="bg-emerald-900/40 px-3 py-2 border-b border-emerald-500/30 flex justify-between items-center">
                    <span className="text-xs font-bold text-emerald-200">paciente</span>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono">1:N a Historial / Citas</span>
                  </div>
                  <div className="p-3 font-mono text-[10px] space-y-1.5">
                    <div className="flex justify-between border-b border-slate-800/50 pb-1 text-slate-200">
                      <span className="font-bold text-yellow-400">🔑 idPaciente</span>
                      <span className="text-slate-400 font-semibold">INT AUTO_INC (PK)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>nombre</span>
                      <span className="text-slate-500">VARCHAR(100)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>especie</span>
                      <span className="text-slate-500">VARCHAR(50)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>raza</span>
                      <span className="text-slate-500">VARCHAR(50)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>edad</span>
                      <span className="text-slate-500">INT</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>fechaNacimiento</span>
                      <span className="text-slate-500">DATE</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-800/50 pt-1 text-indigo-300">
                      <span>🔗 idPropietario</span>
                      <span className="text-slate-400">INT (FK)</span>
                    </div>
                  </div>
                </div>

                {/* Table: Historial Clínico */}
                <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden shadow-lg">
                  <div className="bg-slate-800/50 px-3 py-2 border-b border-slate-800 flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-200">historial_clinico</span>
                    <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono">N:1 a Paciente</span>
                  </div>
                  <div className="p-3 font-mono text-[10px] space-y-1.5">
                    <div className="flex justify-between border-b border-slate-800/50 pb-1 text-slate-200">
                      <span className="font-bold text-yellow-400">🔑 idHistorial</span>
                      <span className="text-slate-400 font-semibold">INT AUTO_INC (PK)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>fecha</span>
                      <span className="text-slate-500">DATE</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>diagnostico</span>
                      <span className="text-slate-500">TEXT</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>tratamiento</span>
                      <span className="text-slate-500">TEXT</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-800/50 pt-1 text-emerald-300">
                      <span>🔗 idPaciente</span>
                      <span className="text-slate-400">INT (FK)</span>
                    </div>
                  </div>
                </div>

                {/* Table: Doctor */}
                <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden shadow-lg">
                  <div className="bg-slate-800/50 px-3 py-2 border-b border-slate-800 flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-200">doctor</span>
                    <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono">1:N a CitaMedica</span>
                  </div>
                  <div className="p-3 font-mono text-[10px] space-y-1.5">
                    <div className="flex justify-between border-b border-slate-800/50 pb-1 text-slate-200">
                      <span className="font-bold text-yellow-400">🔑 idDoctor</span>
                      <span className="text-slate-400 font-semibold">INT AUTO_INC (PK)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>nombre</span>
                      <span className="text-slate-500">VARCHAR(150)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>especialidad</span>
                      <span className="text-slate-500">VARCHAR(100)</span>
                    </div>
                  </div>
                </div>

                {/* Table: Cita Médica */}
                <div className="bg-slate-900 rounded-lg border border-purple-500/30 overflow-hidden shadow-lg">
                  <div className="bg-purple-900/40 px-3 py-2 border-b border-purple-500/30 flex justify-between items-center">
                    <span className="text-xs font-bold text-purple-200">cita_medica</span>
                    <span className="text-[9px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded font-mono">Agenda Inteligente</span>
                  </div>
                  <div className="p-3 font-mono text-[10px] space-y-1.5">
                    <div className="flex justify-between border-b border-slate-800/50 pb-1 text-slate-200">
                      <span className="font-bold text-yellow-400">🔑 idCita</span>
                      <span className="text-slate-400 font-semibold">INT AUTO_INC (PK)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>fecha</span>
                      <span className="text-slate-500">DATE</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>hora</span>
                      <span className="text-slate-500">TIME</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>motivo</span>
                      <span className="text-slate-500">VARCHAR(255)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>tipo</span>
                      <span className="text-slate-500">ENUM('Medica','Estetica')</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-800/50 pt-1 text-emerald-300">
                      <span>🔗 idPaciente</span>
                      <span className="text-slate-400">INT (FK)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>🔗 idDoctor</span>
                      <span className="text-slate-400">INT (FK, NULL)</span>
                    </div>
                  </div>
                </div>

                {/* Table: Servicio Estético */}
                <div className="bg-slate-900 rounded-lg border border-pink-500/30 overflow-hidden shadow-lg">
                  <div className="bg-pink-900/40 px-3 py-2 border-b border-pink-500/30 flex justify-between items-center">
                    <span className="text-xs font-bold text-pink-200">estetico_servicio</span>
                    <span className="text-[9px] bg-pink-500/20 text-pink-300 px-1.5 py-0.5 rounded font-mono">Spa Catálogo</span>
                  </div>
                  <div className="p-3 font-mono text-[10px] space-y-1.5">
                    <div className="flex justify-between border-b border-slate-800/50 pb-1 text-slate-200">
                      <span className="font-bold text-yellow-400">🔑 idServicio</span>
                      <span className="text-slate-400 font-semibold">INT AUTO_INC (PK)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>nombre</span>
                      <span className="text-slate-500">VARCHAR(100)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>costo</span>
                      <span className="text-slate-500">DECIMAL(10,2)</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>duracionMinutos</span>
                      <span className="text-slate-500">INT</span>
                    </div>
                  </div>
                </div>

              </div>

              {/* Integrity summary */}
              <div className="mt-4 p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                  Estrategia de Restricciones e Integridad de Datos (InnoDB)
                </span>
                <ul className="text-[11px] text-slate-400 space-y-1 list-disc list-inside">
                  <li><b className="text-slate-300">ON DELETE CASCADE:</b> Si un propietario se elimina de la base de datos, todas sus mascotas registradas y sus historiales clínicos se purgan automáticamente para evitar registros huérfanos.</li>
                  <li><b className="text-slate-300">ON DELETE SET NULL:</b> Si un doctor renuncia o se elimina del sistema, las citas médicas pasadas conservan el registro como histórico, simplemente marcando el ID del doctor en <code className="bg-slate-950 px-1 py-0.5 rounded text-indigo-300 text-[10px]">NULL</code>.</li>
                  <li><b className="text-slate-300">Índices de Rendimiento:</b> Se crearon índices compuestos <code className="bg-slate-950 px-1 py-0.5 rounded text-indigo-300 text-[10px]">idx_cita_fecha_hora</code> para maximizar la velocidad de carga de la pantalla del Calendario Semanal.</li>
                </ul>
              </div>

            </div>
          </div>
        )}

        {/* TAB 3: LIVE SQL CONSOLE */}
        {activeTab === 'sql_console' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            
            {/* Directives & Pre-made queries helper */}
            <div className="lg:col-span-1 space-y-4">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <span className="text-xs font-bold text-slate-200 block mb-2">Comandos SQL de Prueba</span>
                <p className="text-[10px] text-slate-400 mb-4">
                  Haz clic en cualquiera de estas consultas estructuradas de ejemplo para cargarla en la terminal y ejecutarla en la base de datos MySQL simulada.
                </p>
                <div className="space-y-2.5">
                  <button
                    onClick={() => setSqlQuery("SELECT * FROM propietario;")}
                    className="w-full text-left p-2 bg-slate-900 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/30 rounded text-[10px] font-mono text-slate-300 block transition-all"
                  >
                    SELECT * FROM propietario;
                  </button>
                  <button
                    onClick={() => setSqlQuery("SELECT * FROM paciente WHERE especie = 'Canino';")}
                    className="w-full text-left p-2 bg-slate-900 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/30 rounded text-[10px] font-mono text-slate-300 block transition-all"
                  >
                    SELECT * FROM paciente WHERE especie = 'Canino';
                  </button>
                  <button
                    onClick={() => setSqlQuery("SELECT p.nombre AS Paciente, prop.nombre AS Dueño FROM paciente p JOIN propietario prop ON p.idPropietario = prop.idPropietario;")}
                    className="w-full text-left p-2 bg-slate-900 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/30 rounded text-[10px] font-mono text-slate-300 block transition-all"
                  >
                    SELECT ... JOIN propietario;
                  </button>
                  <button
                    onClick={() => setSqlQuery("SELECT * FROM doctor;")}
                    className="w-full text-left p-2 bg-slate-900 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/30 rounded text-[10px] font-mono text-slate-300 block transition-all"
                  >
                    SELECT * FROM doctor;
                  </button>
                  <button
                    onClick={() => setSqlQuery("INSERT INTO doctor (nombre, especialidad) VALUES ('Dr. Lucas Lima', 'Oftalmología');")}
                    className="w-full text-left p-2 bg-slate-900 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/30 rounded text-[10px] font-mono text-slate-300 block transition-all"
                  >
                    INSERT INTO doctor ...;
                  </button>
                </div>
              </div>
            </div>

            {/* Terminal Window */}
            <div className="lg:col-span-3 space-y-4">
              
              <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-2xl">
                
                {/* Terminal Header */}
                <div className="bg-slate-900 px-4 py-2 flex items-center justify-between border-b border-slate-800">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-yellow-500"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-green-500"></span>
                    <span className="text-[11px] font-mono text-slate-400 ml-2">mysql -u ambar_admin -p -h db-master</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-400">Simulación Activa</span>
                </div>

                {/* SQL Editor Area */}
                <div className="p-4 bg-slate-950">
                  <textarea
                    value={sqlQuery}
                    onChange={(e) => setSqlQuery(e.target.value)}
                    className="w-full h-24 bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded p-3 font-mono text-xs text-slate-200 outline-none resize-none"
                    placeholder="Escribe tu sentencia SQL aquí..."
                  />
                  
                  <div className="flex justify-between items-center mt-3">
                    <div className="text-[10px] text-slate-500">
                      Soporta <code className="bg-slate-900 px-1 rounded">SELECT</code>, <code className="bg-slate-900 px-1 rounded">JOINs</code>, e <code className="bg-slate-900 px-1 rounded">INSERT</code> en vivo.
                    </div>
                    <button
                      onClick={() => executeSQL(sqlQuery)}
                      className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                    >
                      <Play className="w-3.5 h-3.5" />
                      Ejecutar Query (Ctrl + Enter)
                    </button>
                  </div>
                </div>

              </div>

              {/* SQL Result Console Output */}
              <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 min-h-[160px] font-mono text-xs">
                <span className="text-[10px] font-bold text-slate-400 block mb-3 uppercase">Resultados de la consulta</span>

                {/* Error Banner */}
                {sqlError && (
                  <div className="bg-red-950/20 border border-red-500/40 text-red-400 p-3 rounded-lg flex items-start gap-2 animate-shake">
                    <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
                    <div>
                      <span className="font-bold">Error de Motor MySQL:</span>
                      <p className="text-[11px] mt-0.5 text-red-300/90">{sqlError}</p>
                    </div>
                  </div>
                )}

                {/* Success Banner without data (INSERT queries) */}
                {sqlSuccessMessage && !sqlResults && (
                  <div className="bg-emerald-950/20 border border-emerald-500/40 text-emerald-400 p-3 rounded-lg flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="text-[11px]">{sqlSuccessMessage}</span>
                  </div>
                )}

                {/* Grid Results Data Table */}
                {sqlResults && (
                  <div className="space-y-2">
                    <div className="bg-emerald-950/10 border border-emerald-500/30 text-emerald-400 p-2 rounded text-[10px] mb-2">
                      {sqlSuccessMessage}
                    </div>
                    
                    <div className="overflow-x-auto rounded border border-slate-800">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-slate-900 border-b border-slate-800 text-[10px] text-slate-400">
                            {sqlResults.headers.map((h, i) => (
                              <th key={i} className="p-2.5 font-bold uppercase tracking-wider">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800 text-[11px] text-slate-300 bg-slate-950/50">
                          {sqlResults.rows.map((row, rIdx) => (
                            <tr key={rIdx} className="hover:bg-slate-900/60 transition-all">
                              {row.map((cell, cIdx) => (
                                <td key={cIdx} className="p-2.5 font-mono">{cell}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {!sqlError && !sqlSuccessMessage && !sqlResults && (
                  <div className="text-slate-600 italic text-center py-8">
                    La terminal está lista. Escribe o selecciona una consulta y presiona Ejecutar.
                  </div>
                )}

              </div>

            </div>

          </div>
        )}

        {/* TAB 4: PRODUCTION CODE EXPORTS */}
        {activeTab === 'code_exports' && (
          <div className="space-y-4">
            
            <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden">
              
              {/* Export Selector Tab */}
              <div className="bg-slate-900 px-4 py-3 flex items-center justify-between border-b border-slate-800">
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedCodeTab('mysql')}
                    className={`px-3 py-1 rounded text-xs font-bold transition-all ${selectedCodeTab === 'mysql' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                  >
                    esquema_base_datos.sql
                  </button>
                  <button
                    onClick={() => setSelectedCodeTab('php')}
                    className={`px-3 py-1 rounded text-xs font-bold transition-all ${selectedCodeTab === 'php' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                  >
                    Database.class.php
                  </button>
                </div>

                <button
                  onClick={() => copiarAlPortapapeles(selectedCodeTab === 'mysql' ? MYSQL_SCHEMA_SQL : PHP_CONNECTION_CODE)}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded flex items-center gap-1 transition-all"
                >
                  {copiadoCode ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-bold">¡Copiado!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copiar Código</span>
                    </>
                  )}
                </button>
              </div>

              {/* Code Box Area */}
              <div className="p-4 bg-slate-950 overflow-x-auto max-h-[480px] font-mono text-[11px] text-slate-300 leading-relaxed scrollbar-thin">
                <pre className="whitespace-pre">
                  {selectedCodeTab === 'mysql' ? MYSQL_SCHEMA_SQL : PHP_CONNECTION_CODE}
                </pre>
              </div>

            </div>

            <div className="p-4 bg-indigo-950/20 border border-indigo-900/40 rounded-xl">
              <h4 className="text-xs font-bold text-indigo-400 flex items-center gap-1.5 mb-1">
                <Code className="w-3.5 h-3.5" />
                ¿Cómo usar estos archivos en tu servidor de la universidad?
              </h4>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                1. Instala un servidor web local (por ejemplo, XAMPP, Laragon o MAMP) que incluya Apache, PHP 8.x y MySQL 8.x.<br />
                2. Abre <b>phpMyAdmin</b>, crea una nueva base de datos llamada <code className="bg-slate-900 px-1 py-0.5 rounded text-indigo-300 text-[10px]">veterinaria_ambar</code> y ejecuta el código del archivo <code className="bg-slate-900 px-1 py-0.5 rounded text-indigo-300 text-[10px]">esquema_base_datos.sql</code>.<br />
                3. Copia el archivo <code className="bg-slate-900 px-1 py-0.5 rounded text-indigo-300 text-[10px]">Database.class.php</code> en la carpeta de modelos de tu proyecto PHP. Modifica los parámetros de host, usuario y contraseña según los valores de tu servidor local (comúnmente <code className="bg-slate-900 px-1 py-0.5 rounded text-indigo-300 text-[10px]">localhost</code>, usuario <code className="bg-slate-900 px-1 py-0.5 rounded text-indigo-300 text-[10px]">root</code> y contraseña vacía).
              </p>
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
