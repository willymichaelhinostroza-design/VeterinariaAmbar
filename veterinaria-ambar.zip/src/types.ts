export interface Propietario {
  idPropietario: number;
  nombre: string;
  telefono: string;
  email: string;
  direccion: string;
}

export interface Paciente {
  idPaciente: number;
  nombre: string;
  especie: string;
  raza: string;
  edad: number;
  fechaNacimiento: string;
  idPropietario: number;
}

export interface Doctor {
  idDoctor: number;
  nombre: string;
  especialidad: string;
}

export interface HistorialClinico {
  idHistorial: number;
  idPaciente: number;
  fecha: string;
  diagnostico: string;
  tratamiento: string;
}

export interface CitaMedica {
  idCita: number;
  idPaciente: number;
  idDoctor?: number;
  fecha: string;
  hora: string;
  motivo: string;
  tipo: 'Medica' | 'Estetica';
  idServicio?: number;
}

export interface EsteticoServicio {
  idServicio: number;
  nombre: string;
  costo: number;
  duracionMinutos: number;
}

export interface AtencionEstetica {
  idAtencion: number;
  idPaciente: number;
  idServicio: number;
  notas: string;
  costoServicio: number;
  fecha: string;
  comprobanteGenerado: boolean;
}
